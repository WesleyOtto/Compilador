/**
 * windowDownloadInfo namespace.
 */

 function windowDownloadInfo() {

	// --- const
	this.FILE_STATUS_NORMAL = 0;
	this.FILE_STATUS_DOWNLOADING = 1;
	this.FILE_STATUS_DOWNLOADED = 2;
	this.FILE_STATUS_ERROR = 3;
	this.FILE_STATUS_PAUSED = 4;

	try {
		//dump("[windowDownloadInfo] constructor\n");

		this.url = null; // window url
		this.media = {}; // list of downloadable files
		this.haveDownloadLinksWithFormat = false; // this is for youtube special option. If window contents links with format, addition links without format is declined.
		this.adDisplay = false; //state of ad on page
		this.faviconUrl = null; // url to favicon image
		this.sniffer = null; // sniffer object
		this.viewed = false; // flag that shows user view this url or not
		this.adLink = ""; // link to ad

		this.updateComboboxTimeout = null; // this for deffered run of update combobox

	} catch(e) {
		dump("[windowDownloadInfo] !!! constructor: "+e+"\n");
	}
}

windowDownloadInfo.prototype = {}

windowDownloadInfo.prototype._prepareMediaList = function( list ){
	for(var i in list){
		list[i] = this._prepareMediaFile( list[i] );
	}
	return list;
}


windowDownloadInfo.prototype.getAdLink = function(){
	return this.adLink;
}

windowDownloadInfo.prototype.getMedia = function(){
	if(!this.haveDownloadLinksWithFormat){
		return this.media;
	}

	var result = {};
	// filter links without format
	for( var i in this.media ){
		if( !("yt_format" in this.media[i]) ){		// if( !("type" in this.media[i]) ){ везде убрали issue462
			continue;
		}
		result[i] = this.media[i];
	}

	return result;
}

windowDownloadInfo.prototype.getMediaCount = function(){
	return this._objLength( this.media );
}

windowDownloadInfo.prototype.haveDownloadingMedia = function(){
	for( var k in this.media ){
		if( this.media[k].status == this.FILE_STATUS_DOWNLOADING || this.media[k].status == this.FILE_STATUS_PAUSED ){
			return true;
		}
	}
	return false;
}

windowDownloadInfo.prototype._objLength = function (obj){
	var count = 0;
	for( var i in obj ){
		count++;
	}
	return count;
}

windowDownloadInfo.prototype._prepareMediaFile = function( file ){
	if( !("status" in file)){
		file.status = this.FILE_STATUS_NORMAL;
	}
	if( !("downloadId" in file))	file.downloadId = 0;
	if( !("download_info" in file))	file.download_info = [];

	return file;
}

windowDownloadInfo.prototype.setMedia = function( listMedia ){
	this.media = {};
	this.addMediaList( listMedia );
}


windowDownloadInfo.prototype.addMediaFile = function( fileInfo ){
	if (!fileInfo) return false;

	if( (fileInfo.url in this.media) ){
		return false;
	}
	// not add ad
	if( fileInfo.ad ){
		return false;
	}

	if( "yt_format" in fileInfo ){
		this.haveDownloadLinksWithFormat = true;
	}
	else{
		if( this.haveDownloadLinksWithFormat ){
			return false;
		}
	}
	// if this file from youtube(have field yt_format), check for this format already exists in media, if exists not add media
	this.media[fileInfo.url] = this._prepareMediaFile( fileInfo );
}

// ---------------------------------------------------
windowDownloadInfo.prototype.addMediaList = function( listFiles ){
	// pre check for any video that have format and checks if list have ad and not have another links
	var haveAdLinks = false;
	var haveNotAdLinks = false;
	for( var i in listFiles ){
		if( "yt_format" in listFiles[i] ){
			this.haveDownloadLinksWithFormat = true;
		}
		if( listFiles[i].ad ){
			this.adLink = listFiles[i].url;
			haveAdLinks = true;
		}
		else{
			haveNotAdLinks = true;
		}
	}

	// check for only ad
	if( haveAdLinks && !haveNotAdLinks ){
		this.adDisplay = true;
	}
	else{
		this.adDisplay = false;
	}

	// save old media in local var
	var oldMedia = this.media;
	this.media = {};

	for( var i in listFiles ){
		// check if old media have this file
		var foundInOldMedia = false;
		if( i in oldMedia ){
			listFiles[i].status = oldMedia[i].status;
			listFiles[i].downloadId = oldMedia[i].downloadId;
			listFiles[i].download_info = oldMedia[i].download_info;
			if( "size" in oldMedia[i]){
				listFiles[i].size = oldMedia[i].size;
			}


			foundInOldMedia = true;
		}

		if( !foundInOldMedia ){
			if( "yt_format" in listFiles[i] ){
				for( var i in oldMedia ){
					var m = oldMedia[i];
					if( "yt_format" in m ){
						if( listFiles[i] && m.yt_format == listFiles[i].yt_format ){
							listFiles[i].status = m.status;
							listFiles[i].downloadId = m.downloadId;
							listFiles[i].download_info = m.download_info;
							foundInOldMedia = true;
							break;
						}
					}
				}
			}
		}

		this.addMediaFile( listFiles[i] );
	}

	// check if old media have downloading files, then add it to current media if not added

	for( var url in oldMedia ){
		if( oldMedia[url].status == this.FILE_STATUS_DOWNLOADING ){
			if( !( url in this.media ) ){
				this.addMediaFile( oldMedia[url] );
			}
		}
	}
}

windowDownloadInfo.prototype.setFilePlaying = function( url, playing ){
	if( !(url in this.media) ){
		return false;
	}

	this.media[url].playing = playing;

	return true;
}

windowDownloadInfo.prototype._removeNotFormatDownloadLinks = function(){
	// remove from snippets and from internal this.media
	for( var i in this.media ){
		var info = this.media[i];
		if( !("yt_format" in info) ){
			if( info.snipet ){
				var snipet = document.getElementById( info.snipet );
				if( snipet ){
					snipet.parentNode.removeChild( snipet );
				}
			}

			delete this.media[i];
		}
	}
}

windowDownloadInfo.prototype._assignSnipetForMediaUrl = function( mediaUrl, snipetId ){
	for( var i in this.media ){
		var info = this.media[i];
		if( info.url == mediaUrl ){
			this.media[i].snipet = snipetId;
			break;
		}
	}
}

windowDownloadInfo.prototype.setFileStatus = function( url, status ){
	if( !(url in this.media) ){
		return false;
	}

	this.media[url].status = status;

	return true;
}

windowDownloadInfo.prototype.setDownloadId = function( url, downloadId ) {

	if( !( url in this.media ) )	return false;

	this.media[url].downloadId = downloadId;
}

windowDownloadInfo.prototype.setDownload_FullHD = function( url, videoId, audioId )	{
	if( !( url in this.media ) )	return false;

	this.media[url].downloadId = videoId;
	this.media[url].download_info = { video_id: videoId, audio_id: audioId, video_state: false, audio_state: false };

}

windowDownloadInfo.prototype.setFileSize = function( url, size ){

	if( !size ){
		return false;
	}

	if( !( url in this.media ) ){
		return false;
	}

	this.media[url].size = size;

	return true;
}

windowDownloadInfo.prototype.getFileByDownloadId = function( downloadId ){

	for( var i in this.media ){

		if( this.media[i].downloadId == downloadId ){
			return this.media[i];
		}
	}
	return null;
}

windowDownloadInfo.prototype.emptyDownloadId = function( downloadId ){
	for( var i in this.media ){
		if( this.media[i].downloadId == downloadId ){
			this.media[i].downloadId = 0;
			return  true;
		}
	}
	return false;
}


windowDownloadInfo.prototype.getFileByUrl = function( url ){
	if( url in this.media ){
		return this.media[url];
	}
	return null;
},


windowDownloadInfo.prototype._setAdDisplay = function(){
	this.adDisplay = true;
}

windowDownloadInfo.prototype._setAdEnd = function(){
	this.adDisplay = false;
}

