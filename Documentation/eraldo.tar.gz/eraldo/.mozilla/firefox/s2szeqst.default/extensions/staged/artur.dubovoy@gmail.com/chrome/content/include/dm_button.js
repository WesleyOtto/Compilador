/*
 * Insert FVD Download button in youtube interface.
 */

(function(){

	FVD_SINGLE_DM_Button = function(  ){

		this.BUTTON_TITLE = "Download";
		this.BUTTON_FORMATS_TITLE = "Set Default Formats";
		this.BUTTON_FOLDER_TITLE = "Set Default Download folder";
		this.BUTTON_BETTERFOX_TITLE = "Make your Firefox 15% faster!";
		this.BUTTON_ID = "fvd_single_dm_download_button";
		this.BUTTON_TOOLTIP = "Click here to view file formats";
		this.CONVERTER_MENU_TITLE = "Media Converter";
		this.BUTTON_RATING_TITLE = "Rate US!";

		var self = this;
		var doc = null;

		this.clickTimer = null;

		// -------------------------------------------------------
		this.getBrowser_URL = function( page_url ){

			var wm = Components.classes['@mozilla.org/appshell/window-mediator;1'].getService(Components.interfaces.nsIWindowMediator);
			var mwnd = wm.getMostRecentWindow('navigator:browser');
			if ( !mwnd ) return gBrowser.selectedBrowser;

			var gBrowser = mwnd.getBrowser();
			var numTabs = gBrowser.browsers.length;;

			for (var index = 0; index < numTabs; index++)
			{
				var currentBrowser = gBrowser.getBrowserAtIndex(index);
				if (page_url == currentBrowser.currentURI.spec)
				{
					return currentBrowser
				}
			}
			return gBrowser.selectedBrowser;

		};


		// -------------------------------------------------------------------------------------------
		this.insert = function( url )	{

			//dump('FVD_SINGLE_DailyMotion_Button - insert '+ url +'\r\n');
			var bundle = Components.classes['@mozilla.org/intl/stringbundle;1'].getService(Components.interfaces.nsIStringBundleService).createBundle('chrome://fvd.single/locale/fvd.single.properties');

			this.BUTTON_TITLE = bundle.GetStringFromName( "yt_button.title" );
			this.BUTTON_FORMATS_TITLE = bundle.GetStringFromName( "yt_button.formats_title" );
			this.BUTTON_FOLDER_TITLE = bundle.GetStringFromName( "yt_button.folder_title" );
			this.BUTTON_RATING_TITLE = bundle.GetStringFromName( "yt_button.rating_title" );
			this.CONVERTER_MENU_TITLE = bundle.GetStringFromName( "yt_button.converter_menu_title" );

			var browser = this.getBrowser_URL( url );
			doc = browser.contentDocument;

			if( !doc.getElementById(this.BUTTON_ID) ){

				var button = this.createButtonElementDM( this.BUTTON_ID );

				this.fvdButton = button;

				var ff = fvd_single.registry.getBoolPref('install_setting');

				button.addEventListener("click", function(event){

					if (ff) {
						fvd_single.show_FVD_install_setting( true );
					}

					var doc = gBrowser.selectedBrowser.contentDocument;
					var location = gBrowser.webNavigation.currentURI;
					var sniffedMedia = fvd_single.prepareSniffedMedia( doc, fvd_single.sniffer.get_files_all() );

					var media = {};
					media = fvd_single.extendMediaByUrl( sniffedMedia, media, location.spec );

					if( media[location.spec] )
					{
						media = media[location.spec];

						self.buildMediaListDM( media, button, null );
					}

				}, false);

				var block = doc.querySelector('.pl_video_infos');
				if ( !block ) return;
				block.setAttribute("style", "overflow: visible");

				var elemFlag_media = block.querySelector('.media');
				elemFlag_media.setAttribute("style", "width:400px; overflow: visible");

				var elemFlag_row = elemFlag_media.parentNode;
				elemFlag_row.setAttribute("style", "overflow: visible");

				if( elemFlag_media )	{
					var elemFlag_foreground = block.querySelector('.media-block');
					elemFlag_foreground.setAttribute("style", "float:left; width: 160px;");

					var dv = doc.createElement("div");
					dv.appendChild( button );
					elemFlag_media.appendChild( dv );

					elemFlag_next = elemFlag_media.nextElementSibling;
					elemFlag_next.setAttribute("style", "float:right; width: auto;");

					var div = doc.createElement("div");
					div.setAttribute("style", "display: none; z-index: 30; position:relative; margin-left:150px");
					div.setAttribute("id", "download_container");
					dv.appendChild( div );
				}

			}
		}

		// -------------------------------------------------------------------------------------------
		this.createButtonElementDM = function( buttonId )	{

			var button = doc.createElement("button");
			button.setAttribute("class", "tool_addto icn_right button action:toggleOrUpdate action:arg0:#moveto_container");
			button.setAttribute("data-tooltip",  this.BUTTON_TOOLTIP);
			button.setAttribute("title",  this.BUTTON_TOOLTIP);
			button.setAttribute("type", "button");
			button.setAttribute("style", "padding:5px; margin-top: 20px; font-weight: bold; font-family: arial,sans-serif; font-size: 13px;");
			button.setAttribute("id", this.BUTTON_ID);

			var div1 = doc.createElement("div1");
			div1.setAttribute("style",  "margin-right:5px; float:left");
			var img = doc.createElement("img");
			img.setAttribute("src",  fvd_single_Formats.getAccessibleImage("fvd"));
			img.setAttribute("align",  "left");
			div1.appendChild( img );
			button.appendChild( div1 );

			var div2 = doc.createElement("div");
			div2.setAttribute("style",  "float:left;  margin-top: -7px;");
			div2.textContent = this.BUTTON_TITLE;
			button.appendChild( div2 );

			var div3 = doc.createElement("div");
			div3.setAttribute("class",  "icn_wrap");
			div3.setAttribute("style",  "float:left; border-left:1px solid; margin-left:5px; width:20px; padding-left:5px; height:14px");
			var img1 = doc.createElement("img");
			img1.setAttribute("src",  fvd_single_Formats.getAccessibleImage("arrow_down"));
			img1.setAttribute("align",  "left");
			div3.appendChild( img1 );
			button.appendChild( div3 );

			button.addEventListener( "click", function( event ){

							window.clearTimeout(self.clickTimer);

							var doc = gBrowser.selectedBrowser.contentDocument;
							var elem = doc.getElementById('download_container');

							var x = elem.getAttribute("style");

					        if( x.indexOf( "none" ) != -1 )
							{
								elem.setAttribute("style", "display: block; z-index: 30; position:relative; margin-left:200px");
								doc.addEventListener("click", self.click_document, true);
							}
							else
							{
								doc.removeEventListener("click", self.click_document, true);
								elem.setAttribute("style", "display: none; z-index: 30; position:relative; margin-left:200px");
							}
						}, true );

			return button;

		}

		// -------------------------------------------------------------------------------------------
		this.click_document = function(  )	{

			var doc = gBrowser.selectedBrowser.contentDocument;

			self.clickTimer = setTimeout(function() {

						var elem = doc.getElementById('download_container');
						elem.style.display = 'none';

					},  100 );

		}

		// -------------------------------------------------------------------------------------------
		this.buildMediaListDM = function( media, button, buttonId, item )  {

			var doc = gBrowser.selectedBrowser.contentDocument;
			var location = gBrowser.webNavigation.currentURI;

			var parent = doc.getElementById( "download_container" );

			var menus = doc.getElementById('download_menu');

			var menu = null;
			if( menus )		{
				while( menus.firstChild )	{
					menus.removeChild( menus.firstChild );
				}
				menu = menus;
			}
			else	{
				menu = doc.createElement( "div" );
				menu.setAttribute( "class", "dmco_html dmpi_video_list_moveto dmco_select chrome_options foreground2 light_border background" );
				menu.setAttribute( "style", "position: absolute; top: -1px;	left: -95px; border: 1px solid #ddd; -webkit-box-shadow: rgba(0,0,0,0.3) 0 0 1px; -moz-box-shadow: rgba(0,0,0,0.3) 0 0 1px;	margin-right: 0; padding: 8px 0 4px; background-color: white;  cursor: pointer;" );
				menu.setAttribute("id", "download_menu");
				parent.appendChild(menu);
			}

			for( var k in media )	{
				var m = media[k];
				if( !fvd_single.check_shows_format( m.ext, location.spec )) continue;

				var size = m.sz;

				var imageUrl = "";
				if( "ext" in m )	imageUrl = fvd_single_Formats.getAccessibleImage(m.ext);

				var spani = doc.createElement( "span" );
				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("src", imageUrl);
				spani.appendChild(img);

				var txt = doc.createElement( "span" );
				txt.setAttribute("style", "margin-left:5px; float:left");
				txt.textContent = m.raw_file_ext;

				var sp = doc.createElement( "span" );
				sp.setAttribute("style", "clear: both");


				var span = doc.createElement("div");
				span.setAttribute( "class", "dm_button_select_item" );
				span.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");
				span.appendChild( spani );
				span.appendChild( txt );
				span.appendChild( sp );

				(function( medToDownload, span ){
								span.addEventListener("click", function(){
												try	{
													var urlHash = "yt_hash" in medToDownload && medToDownload.yt_hash ? medToDownload.yt_hash : fvd_single_Misc.md5( medToDownload.url );

													fvd_single.downloadInstance.downloadByWindow( 	urlHash,
																									medToDownload.url,
																									medToDownload.url.download_name ? medToDownload.download_name : medToDownload.file_title,
																									"." + medToDownload.ext,
																									medToDownload.root_url,
																									medToDownload.referer,
																									function( downloadId ){	}
																								);
												}
												catch( ex )
												{
													dump( "DM_BUTTON: ERROR WHILE START DOWNLOAD: " + ex + "\n" );
												}

											}, true);
								span.addEventListener("mouseover", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important; background:rgb(0, 121, 184); color: white");
											}, true);
								span.addEventListener("mouseout", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");
											}, true);
							})( m, span );

				menu.appendChild( span );
			}

			this.createSeparator( menu );
			this.createSetLi( menu, 'formats' );
			this.createSetLi( menu, 'folder' );
			this.createSetLi( menu, 'wallpapers' );
			this.createSetLi( menu, 'nimbus' );
		}

		// -------------------------------------------------------------------------------------------
		this.createSeparator = function( menu )  {
			var doc = gBrowser.selectedBrowser.contentDocument;
			var sp = doc.createElement("span");
			var span = doc.createElement( "span" );
			span.setAttribute( "style", "display: block; width:250px; height:5px; border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 1px;	border-bottom-width: 0px;  border-color: #999; color: #202020;" );
			sp.appendChild( span );
			menu.appendChild( sp );
		}

		// -------------------------------------------------------------------------------------------
		this.createSetLi = function( menu, type )  {

			var doc = gBrowser.selectedBrowser.contentDocument;

			var span = doc.createElement( "div" );
			span.setAttribute( "class", "dm_button_select_item" );
			span.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");

			if (type == 'formats')	{
				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("src", fvd_single_Formats.getAccessibleImage("set"));
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px; float:left" );
				span_t.textContent = this.BUTTON_FORMATS_TITLE;
				span.appendChild(span_t);


				(function( span ){
								span.addEventListener("click", function(){
											fvd_single.set_file_types();
										}, true);
								span.addEventListener("mouseover", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important; background:rgb(0, 121, 184); color: white");
											}, true);
								span.addEventListener("mouseout", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");
											}, true);
							})( span );
			}
			else if (type == 'folder')	{
				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("src", fvd_single_Formats.getAccessibleImage("set"));
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;  float:left" );
				span_t.textContent = this.BUTTON_FOLDER_TITLE;
				span.appendChild(span_t);


				(function( span ){
								span.addEventListener("click", function(){
											fvd_single.set_default_folder();
										}, true);
								span.addEventListener("mouseover", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important; background:rgb(0, 121, 184); color: white");
											}, true);
								span.addEventListener("mouseout", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");
											}, true);
							})( span );
			}
			else if (type == 'betterfox')	{
				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("src", fvd_single_Formats.getAccessibleImage("bet"));
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;  float:left" );
				span_t.textContent = 'Make your Firefox 15% faster!';
				span.appendChild(span_t);

				(function( span ){
								span.addEventListener("click", function(){
											fvd_single.navigate_url( 'https://addons.mozilla.org/En-us/firefox/addon/betterfox/' );
										}, true);
								span.addEventListener("mouseover", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important; background:rgb(0, 121, 184); color: white");
											}, true);
								span.addEventListener("mouseout", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");
											}, true);
							})( span );
			}
			else if (type == 'wallpapers')	{
				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("src", fvd_single_Formats.getAccessibleImage("wal"));
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;  float:left" );
				span_t.textContent = 'Live Wallpapers in Browser!';
				span.appendChild(span_t);

				(function( span ){
								span.addEventListener("click", function(){
											fvd_single.navigate_url( 'https://addons.mozilla.org/firefox/addon/live-start-page-lst/' );
										}, true);
								span.addEventListener("mouseover", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important; background:rgb(0, 121, 184); color: white");
											}, true);
								span.addEventListener("mouseout", function(){
												this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");
											}, true);
							})( span );
			}
			else if (type == 'nimbus')	{
				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("src", fvd_single_Formats.getAccessibleImage("nim"));
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;  float:left" );
				span_t.textContent = 'Make Screenshot,Edit,Upload';
				span.appendChild(span_t);

				(function( span ){
							span.addEventListener("click", function(){
										fvd_single.navigate_url( 'https://addons.mozilla.org/en-US/firefox/addon/nimbus-Screenshot/' );
									}, true);
							span.addEventListener("mouseover", function(){
											this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important; background:rgb(0, 121, 184); color: white");
										}, true);
							span.addEventListener("mouseout", function(){
											this.setAttribute("style", "width:250px; height: 30px; padding: 6px 6px 6px 10px !important;");
										}, true);
						})( span );
			}

			menu.appendChild( span );
		}



// ================================================================================================
	}
})();
