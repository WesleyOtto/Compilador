/*
 * Insert FVD Download button in youtube interface.
 */

(function(){

	FVD_SINGLE_FB_Button = function(  ){

		this.BUTTON_TITLE = "Download";
		this.BUTTON_FORMATS_TITLE = "Set Default Formats";
		this.BUTTON_FOLDER_TITLE = "Set Default Download folder";
		this.BUTTON_BETTERFOX_TITLE = "Make your Firefox 15% faster!";
		this.BUTTON_ID = "fvd_single_dm_download_button";
		this.BUTTON_TOOLTIP = "Click here to view file formats";

		var self = this;
		var doc = null;

		this.clickTimer = null;

		// -------------------------------------------------------
		this.getBrowser_URL = function( page_url ){

			var wm = Components.classes['@mozilla.org/appshell/window-mediator;1'].getService(Components.interfaces.nsIWindowMediator);
			var mwnd = wm.getMostRecentWindow('navigator:browser');
			if ( !mwnd ) return gBrowser.selectedBrowser;

			var gBrowser = mwnd.getBrowser();
			var numTabs = gBrowser.browsers.length;;

			for (var index = 0; index < numTabs; index++)
			{
				var currentBrowser = gBrowser.getBrowserAtIndex(index);
				if (page_url == currentBrowser.currentURI.spec)
				{
					return currentBrowser
				}
			}
			return gBrowser.selectedBrowser;

		};



		// -------------------------------------------------------------------------------------------
		this.insert = function( str )	{

			var data = JSON.parse(str);

			var divId = data.id;

			var doc = gBrowser.selectedBrowser.contentDocument;

			if ( doc.getElementById( "download_" + divId ) ) return;

			if ( divId ) {

				var block = doc.getElementById(divId);

				if (block) {
					var e = find_action( block );
					add_icon( e, data );
				}

			}

			// ------------------------------
			function find_action( block ) {

				var ff = block.querySelector('form.commentable_item');
				if ( !ff ) return null;

				var fff = ff.querySelector('div');
				if ( !fff ) return null;
				var fff = fff.querySelector('div._37uu');
				if ( !fff ) return null;

				var ee = fff.querySelector('div._42nr');
				if (ee) var sp = ee.querySelector('span');

				if (sp) {
					return sp;
				}

				return null;
			}

			// ------------------------------
			function add_icon( elem, m ) {

				if (!elem) return;

				var id = "download_" + m.id;

				if ( doc.getElementById( id ) ) return;

				var span = doc.createElement("span");
				span.setAttribute("id", id);
				span.setAttribute("style", "float: left; margin-top: 3px; cursor: pointer;");
				elem.parentNode.insertBefore( span, elem );

				var div = doc.createElement("div");
				div.setAttribute("title", "Download");
				span.appendChild( div );

				div.addEventListener("click", function(e){
						try	{
							var urlHash = m.hash;

							fvd_single.downloadInstance.downloadByWindow( 	urlHash,
																			m.url,
																			m.download_name,
																			"." + m.ext,
																			m.root_url,
																			'',
																			function( downloadId ){	}
																		);
							e.stopPropagation();
						}
						catch( ex )	{
							dump( "DM_BUTTON: ERROR WHILE START DOWNLOAD: " + ex + "\n" );
						}
				}, true);

				var img = doc.createElement("img");
				img.setAttribute("src",  fvd_single_Formats.getAccessibleImage("fvd"));
				div.appendChild( img );

			}

		}




// ================================================================================================
	}
})();
