/*
 * Insert flash video downloader links in Vkontakte pages
 */

(function(){

	FVD_SINGLE_VK_Button = function(  ){

		this.BUTTON_TITLE = "Download";
		this.BUTTON_FORMATS_TITLE = "Set Default Formats";
		this.BUTTON_FOLDER_TITLE = "Set Default Download folder";
		this.BUTTON_BETTERFOX_TITLE = "Make your Firefox 15% faster!";
		this.BUTTON_ID = "fvd_single_vk_download_button";
		this.BUTTON_TOOLTIP = "Click here to view file formats";
		this.CONVERTER_MENU_TITLE = "Media Converter";
		this.BUTTON_RATING_TITLE = "Rate US!";

		var self = this;

		this.clickTimer = null;

		// -------------------------------------------------------------------------------------------
		this.insert = function( item )	{

			var bundle = Components.classes['@mozilla.org/intl/stringbundle;1'].getService(Components.interfaces.nsIStringBundleService).createBundle('chrome://fvd.single/locale/fvd.single.properties');

			this.BUTTON_TITLE = bundle.GetStringFromName( "yt_button.title" );
			this.BUTTON_FORMATS_TITLE = bundle.GetStringFromName( "yt_button.formats_title" );
			this.BUTTON_FOLDER_TITLE = bundle.GetStringFromName( "yt_button.folder_title" );
			this.BUTTON_RATING_TITLE = bundle.GetStringFromName( "yt_button.rating_title" );
			this.CONVERTER_MENU_TITLE = bundle.GetStringFromName( "yt_button.converter_menu_title" );

			var doc = gBrowser.selectedBrowser.contentDocument;

			if( !doc.getElementById(this.BUTTON_ID) ){

				var button = this.createButtonElementVK( this.BUTTON_ID );

				this.fvdButton = button;

				button.addEventListener("click", function(event){

								var location = gBrowser.webNavigation.currentURI;
								var sniffedMedia = fvd_single.prepareSniffedMedia( doc, fvd_single.sniffer.get_files_all() );

								var media = {};
								media = fvd_single.extendMediaByUrl( sniffedMedia, media, location.spec );

								if( media[location.spec] )
								{
									media = media[location.spec];

									self.buildMediaListVK( media, button, null, item );
								}

							}, false);

				var elemFlag = doc.getElementById("mv_controls_line");
				if (!elemFlag) {
					var block = doc.getElementById("mv_content").querySelector('.wrap');;
					elemFlag = doc.createElement("div");
					elemFlag.setAttribute("style",  "height: 30px; width:100%; background: black;");
					block.appendChild( elemFlag );
				}
				else {
					elemFlag.style.display = "block";
				}

				var dv = doc.createElement("div");
				dv.setAttribute("style", "margin-top: 3px; margin-right: 30px; float:right; ");
				dv.appendChild( button );
				elemFlag.appendChild( dv );

				var div = doc.createElement("div");
				div.setAttribute("style", "display: none; z-index: 30; position:relative;");
				div.setAttribute("id", "download_container");
				dv.appendChild( div );
			}
		}

		// -------------------------------------------------------------------------------------------
		this.createButtonElementVK = function( buttonId )	{

			var doc = gBrowser.selectedBrowser.contentDocument;

			var span1 = doc.createElement("span");
			span1.setAttribute("style",  "margin-right:5px; ");

			var img = doc.createElement("img");
			img.setAttribute("src",  fvd_single_Formats.getAccessibleImage("fvd"));
			img.setAttribute("align",  "left");
			span1.appendChild( img );

			var span2 = doc.createElement("span");
			span2.setAttribute("style",  "background: url(/images/darr_on.gif) 0px 0px; width: 7px; height: 4px; display: inline-block; margin-bottom: 3px; margin-left: 5px; ");

			var span3 = doc.createElement("span");
			span3.setAttribute("style",  "width: 7px; height: 14px; display: inline-block;  position:absolute; top: 3px; left: 90px;  border-color: black; border-style: solid;  border-width: 0px 0px 0px 1px;	");
			span3.appendChild( span2 );


			var span = doc.createElement("span");
			span.setAttribute("style",  "display: inline-block; position:absolute; top: 2px; left: 25px; ");
			span.textContent = this.BUTTON_TITLE;

			var button = doc.createElement("button");

			//button.setAttribute("class", "tool_addto icn_right button action:toggleOrUpdate action:arg0:#moveto_container");
			button.setAttribute("data-tooltip",  this.BUTTON_TOOLTIP);
			button.setAttribute("title",  this.BUTTON_TOOLTIP);
			button.setAttribute("type", "button");
			button.setAttribute("id", this.BUTTON_ID);
			button.setAttribute("style",  "width:110px; height: 24px; padding: 0; position: relative");

			button.appendChild( span1 );
			button.appendChild( span );
			button.appendChild( span3 );

			button.addEventListener( "click", function( event ){

							window.clearTimeout(self.clickTimer);

							var elem = doc.getElementById('download_container');

							var x = elem.getAttribute("style");

					        if( x.indexOf( "none" ) != -1 )
							{
								elem.setAttribute("style", "display: block; z-index: 30; position:relative;");
								doc.addEventListener("click", self.click_document, true);
							}
							else
							{
								doc.removeEventListener("click", self.click_document, true);
								elem.setAttribute("style", "display: none; z-index: 30; position:relative;");
							}
						}, true );

			return button;
		}

 		// -------------------------------------------------------------------------------------------
		this.click_document = function(  )	{

			var doc = gBrowser.selectedBrowser.contentDocument;

			self.clickTimer = setTimeout(function() {

						var elem = doc.getElementById('download_container');
						if (elem) elem.style.display = 'none';

					},  100 );

		}

		// -------------------------------------------------------------------------------------------
		this.buildMediaListVK = function( media, button, buttonId, item )  {

			var doc = gBrowser.selectedBrowser.contentDocument;
			var location = gBrowser.webNavigation.currentURI;

			var parent = doc.getElementById( "download_container" );

			var menus = doc.getElementById('download_menu');

			var menu = null;
			if( menus )	{
				while( menus.firstChild )	{
					menus.removeChild( menus.firstChild );
				}
				menu = menus;
			}
			else	{
				menu = doc.createElement( "div" );
				menu.setAttribute( "style", "position: absolute; top: -1px; left: 0; border: 1px solid #ddd; -webkit-box-shadow: rgba(0,0,0,0.3) 0 0 1px; -moz-box-shadow: rgba(0,0,0,0.3) 0 0 1px; margin-right: 0; padding: 8px 0 4px; z-index: 20; color: #666666; text-align: left;   font: 13px Arial,Helvetica,Clean,Sans-serif; background:white;" );
				menu.setAttribute("id", "download_menu");
				parent.appendChild(menu);
			}

			var kk = 0;
			for( var k in media )	{
				var m = media[k];
				if( !fvd_single.check_shows_format( m.ext, location.spec )) continue;

				var size = m.sz;

				var imageUrl = "";
				if( "ext" in m ) imageUrl = fvd_single_Formats.getAccessibleImage(m.ext);

				var spani = doc.createElement( "span" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("src", imageUrl);
				spani.appendChild(img);

				var txt = doc.createElement( "span" );
				txt.setAttribute("style", "margin-left:5px;");
				txt.textContent = m.raw_file_ext;

				var span = doc.createElement("a");
				span.setAttribute("class", "mvs_act");
				span.setAttribute("style", "width:100px; padding: 6px 6px 6px 10px !important; display: block;   font-size: 13px;    height: 16px;   white-space: nowrap; cursor:pointer;");

				span.setAttribute("id", "download_menu");
				span.appendChild( spani );
				span.appendChild( txt );

				(function( medToDownload, span ){
								span.addEventListener("click", function(){
												try	{
													fvd_single.downloadInstance.downloadByWindow(
																		("yt_hash" in medToDownload && medToDownload.yt_hash ? medToDownload.yt_hash : fvd_single_Misc.md5( medToDownload.url )),
																		medToDownload.url,
																		medToDownload.url.download_name ? medToDownload.download_name : medToDownload.file_title,
																		"." + medToDownload.ext,
																		medToDownload.root_url,
																		medToDownload.referer,
																		function( downloadId ){	}
																	);
												} catch( ex ) {
													dump( "VK_BUTTON VIDEO: ERROR WHILE START DOWNLOAD: " + ex + "\n" );
												}
											}, true);
								span.addEventListener("mouseover", function(){
												span.style.background = "#cde0e6";
											}, true);
								span.addEventListener("mouseout", function(){
												span.style.background = "white";
											}, true);
							})( m, span );

				menu.appendChild( span );
				kk++;
			}

			if (kk==0) {
				fvd_single.button_DailyMotion.createSetLi( menu, 'formats' );
			}

		}
		// -------------------------------------------------------------------------------------------
		this.insertIcon = function( item )	{

			var doc = gBrowser.selectedBrowser.contentDocument;
			var location = gBrowser.webNavigation.currentURI;
			var sniffedMedia = fvd_single.prepareSniffedMedia( doc, fvd_single.sniffer.get_files_all() );

			var media = {};
			media = fvd_single.extendMediaByUrl( sniffedMedia, media, location.spec );

			if( media[location.spec] )
			{
				media = media[location.spec];

				self.buildMediaIconVK( media );
			}



		}
		// -------------------------------------------------------------------------------------------
		this.buildMediaIconVK = function( media )  {

			var doc = gBrowser.selectedBrowser.contentDocument;
			var location = gBrowser.webNavigation.currentURI;

			for( var k in media )
			{
				var m = media[k];
				var id = m.yt_format;

				var elem_play = doc.getElementById("play" + id);
				elem_play.parentNode.setAttribute("style", "padding-left:2px");

				var elem_div = elem_play.parentNode.parentNode;
				var elem_parent = elem_div.parentNode;

				var dd = doc.getElementById("download" + id);
				if (dd != null) continue;

				var div = doc.createElement("div");
				div.setAttribute("class", "play_btn fl_l");
				div.setAttribute("id", "download" + id);
				div.setAttribute("style", "width:20px");

				var div1 = doc.createElement("div");
				div1.setAttribute("class", "play_btn_wrap");
				div1.setAttribute("style", "padding-left:0px");
				div.appendChild( div1 );

				var div2 = doc.createElement("div");
				div2.setAttribute("style", "width:16px; height:16px; float:left;");
				div2.setAttribute("title", "Download");
				div1.appendChild( div2 );

				(function( medToDownload, div ){
								div.addEventListener("click", function(){
												try
												{
													fvd_single.downloadInstance.downloadByWindow(
																		("yt_hash" in medToDownload && medToDownload.yt_hash ? medToDownload.yt_hash : fvd_single_Misc.md5( medToDownload.url )),
																		medToDownload.url,
																		medToDownload.url.download_name ? medToDownload.download_name : medToDownload.file_title,
																		"." + medToDownload.ext,
																		medToDownload.root_url,
																		medToDownload.referer,
																		function( downloadId ){	}
																	);
												}
												catch( ex )
												{
													dump( "VK_BUTTON AUDIO: ERROR WHILE START DOWNLOAD: " + ex + "\n" );
												}
											}, true);
							})( m, div2 );

				var img = doc.createElement("img");
				img.setAttribute("src",  fvd_single_Formats.getAccessibleImage("fvd"));
				div2.appendChild( img );

				elem_parent.insertBefore( div, elem_div );

				var div_info = elem_parent.getElementsByClassName("info fl_l");
				if (div_info[0])	div_info[0].setAttribute("style", "width:375px");

			}


		}




// ================================================================================================
	}
})();

