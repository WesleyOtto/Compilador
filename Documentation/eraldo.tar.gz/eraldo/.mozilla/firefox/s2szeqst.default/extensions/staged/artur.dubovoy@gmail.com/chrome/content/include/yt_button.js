/*
 * Insert FVD Download button in youtube interface.
 */

(function(){

	FVD_SINGLE_YT_Button = function(  ){

		this.BUTTON_TITLE = "Download";
		this.BUTTON_FORMATS_TITLE = "Set Default Formats";
		this.BUTTON_FOLDER_TITLE = "Set Default Download folder";
		this.BUTTON_BETTERFOX_TITLE = "Make your Firefox 15% faster!";
		this.BUTTON_ID = "fvd_single_yt_download_button";
		this.BUTTON_TOOLTIP = "Click here to view file formats";
		this.CONVERTER_MENU_TITLE = "Media Converter";
		this.BUTTON_RATING_TITLE = "Rate US!";
		this.NOTE_TAKING_MENU_TITLE = "Best note-taking software";

		this.ELEMENT_YOUTUBE_INSERT = "watch7-views-info";

		var self = this;
		var doc = null;

		this.type_os = null;
		this.message_ffmpeg = false;

		// -------------------------------------------------------
		this.getBrowser_URL = function( page_url ){

			var wm = Components.classes['@mozilla.org/appshell/window-mediator;1'].getService(Components.interfaces.nsIWindowMediator);
			var mwnd = wm.getMostRecentWindow('navigator:browser');
			if ( !mwnd ) return gBrowser.selectedBrowser;

			var gBrowser = mwnd.getBrowser();
			var numTabs = gBrowser.browsers.length;;

			for (var index = 0; index < numTabs; index++)
			{
				var currentBrowser = gBrowser.getBrowserAtIndex(index);
				if (page_url == currentBrowser.currentURI.spec)
				{
					return currentBrowser
				}
			}
			return gBrowser.selectedBrowser;

		};


		// -------------------------------------------------------------------------------------------
		this.insert = function( url )	{

			this.message_ffmpeg = fvd_single.message_ffmpeg;
			this.type_os = fvd_single_Misc.getOS();

			//dump('FVD_SINGLE_YT_Button - insert '+ url + ' - '+this.type_os+'\r\n');
			var bundle = Components.classes['@mozilla.org/intl/stringbundle;1'].getService(Components.interfaces.nsIStringBundleService).createBundle('chrome://fvd.single/locale/fvd.single.properties');

			this.BUTTON_TITLE = bundle.GetStringFromName( "yt_button.title" );
			this.BUTTON_FORMATS_TITLE = bundle.GetStringFromName( "yt_button.formats_title" );
			this.BUTTON_FOLDER_TITLE = bundle.GetStringFromName( "yt_button.folder_title" );
			this.BUTTON_RATING_TITLE = bundle.GetStringFromName( "yt_button.rating_title" );
			this.CONVERTER_MENU_TITLE = bundle.GetStringFromName( "yt_button.converter_menu_title" );
			this.NOTE_TAKING_MENU_TITLE = bundle.GetStringFromName( "yt_button.note_taking_menu_title" );

			this.full_HD = false;

			var browser = this.getBrowser_URL( url );
			doc = browser.contentDocument;

			if( doc.getElementsByTagName("body").length == 0 || doc.getElementById( this.ELEMENT_YOUTUBE_INSERT ) == null)  {
				doc.addEventListener("DOMContentLoaded", function(){
											self.insert( url );
										}, false);
				return;
			}

			if( !doc.getElementById(this.BUTTON_ID) )	{

				var button = this.createButton( this.BUTTON_ID, this.BUTTON_TOOLTIP );

				this.fvdButton = button;

				var ff = fvd_single.registry.getBoolPref('install_setting');

				button.addEventListener("click", function(event){


					if (ff) {
						fvd_single.show_FVD_install_setting( true );
					}

					var doc = gBrowser.selectedBrowser.contentDocument;
					var location = gBrowser.webNavigation.currentURI;
					var sniffedMedia = fvd_single.prepareSniffedMedia( doc, fvd_single.sniffer.get_files_all() );

					var media = {};
					media = fvd_single.extendMediaByUrl( sniffedMedia, media, location.spec );

					if( media[location.spec] )
					{
						media = media[location.spec];

						self.buildMediaList( media, button, null );
					}

				}, false);


				var elemFlag = doc.getElementById( this.ELEMENT_YOUTUBE_INSERT );

				if( elemFlag )	{
					elemFlag.parentNode.insertBefore(button, elemFlag);
				}
				else	{
					var actionsDiv = doc.getElementById('watch-actions-right');

					if( !actionsDiv )	{
						var actionsDiv = doc.getElementById('watch7-sentiment-actions');
					}

					//dump( "Actions div is: " + actionsDiv + "\n" );

					if( actionsDiv )	{
						actionsDiv.appendChild(button);
					}
				}

			}

			if( doc.location.href.indexOf( "youtube.com/user/" ) != -1 )	{
				if( !doc.getElementById(this.BUTTON_ID) )	{
					var button = this.createButton( this.BUTTON_ID, this.BUTTON_TOOLTIP );

					this.fvdButton = button;

					button.addEventListener("click", function(event){

								var doc = gBrowser.selectedBrowser.contentDocument;
								var location = gBrowser.webNavigation.currentURI;
								var sniffedMedia = fvd_single.prepareSniffedMedia( doc, fvd_single.sniffer.get_files_all() );

								var media = {};
								media = fvd_single.extendMediaByUrl( sniffedMedia, media, location.spec );

								if( media[location.spec] )
								{
									media = media[location.spec];

									self.buildMediaList( media, button, null );
								}

							}, false);

					var elemFlag = doc.getElementById( "channel-navigation-menu" );

					if( elemFlag )	{
						var li = doc.createElement("li");
						li.setAttribute( "style", "margin-left: 200px;" );
						li.appendChild( button );
						elemFlag.appendChild(li);
					}
					else	{
						var actionsDiv = doc.getElementsByClassName('video-content-info')[0];
						if( actionsDiv )  {
							var div = doc.createElement("div");
							div.setAttribute( "style", "margin-left: 50px; margin-top: 20px;" );
							div.appendChild( button );
							actionsDiv.appendChild(div);
						}
					}
				}
			}

		}

		// -------------------------------------------------------------------------------------------
		this.createButton = function( buttonId, tooltip )  {

			//dump("FVD_SINGLE_YT_Button - createButton " + buttonId + " -- " + tooltip + "\r\n");
			//var doc = gBrowser.selectedBrowser.contentDocument;

			var button = doc.createElement("button");
			button.setAttribute("data-button-listener", "");
			button.setAttribute("data-tooltip-timer", "271");
			button.setAttribute("class", "end flip yt-uix-button yt-uix-button-default yt-uix-button-empty");
			button.setAttribute("data-tooltip", tooltip);
			button.setAttribute("style", "margin-left: 20px; border: solid;	border-right-width: 1px;	border-left-width: 1px;	border-top-width: 1px;	border-bottom-width: 1px;  border-color: #999;");
			button.setAttribute("type", "button");
			button.setAttribute("id", buttonId);

			var imageUrl = fvd_single_Formats.getAccessibleImage( 'fvd' );

			var span_img = doc.createElement("span");
			span_img.setAttribute("class", "yt-uix-button-content yt-uix-button-icon-wrapper");
			var img = doc.createElement("img");
			img.setAttribute("align", "left");
			img.setAttribute("src", imageUrl);
			span_img.appendChild(img);
			button.appendChild(span_img);

			var span_title = doc.createElement("span");
			span_title.setAttribute("style", "padding-left:5px;line-height:23px; padding-right:10px; border: solid; border-right-width:1px; border-left-width:0px; border-top-width:0px; border-bottom-width:0px;");
			span_title.textContent = this.BUTTON_TITLE;
			button.appendChild(span_title);

			var img = doc.createElement("img");
			img.setAttribute("class", "yt-uix-button-arrow yt-uix-button-icon-wrapper");
			img.setAttribute("style", "margin-left:10px;" );
			img.setAttribute("id","yt_btn");
			img.setAttribute("src","//s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif");
			button.appendChild(img);

			var ul = doc.createElement("ul");
			ul.setAttribute("class", "yt-uix-button-menu");
			ul.setAttribute("style","display:none");
			ul.setAttribute("id", "fvd-yt-uix-button-menu");
			button.appendChild(ul);

			return button;
		}

		// -------------------------------------------------------------------------------------------
		this.buildMediaList = function( media, button, buttonId )  {

			var doc = gBrowser.selectedBrowser.contentDocument;
			var location = gBrowser.webNavigation.currentURI;

			var menu = doc.getElementById( "fvd-yt-uix-button-menu" );
			if(menu != null)  {
				while( menu.firstChild )  {
					menu.removeChild( menu.firstChild );
				}
			}
			else  {
				menu = doc.createElement( "ul" );
				menu.setAttribute( "class", "yt-uix-button-menu" );
				menu.setAttribute("id", "fvd-yt-uix-button-menu");
				button.appendChild(menu);
			}

			for( var k in media ) {
				var m = media[k];

				if ( ! fvd_single.check_shows_format( m.ext, location.spec ) ) continue;

				if ( ! fvd_single.check_shows_type( m.yt_type, location.spec ) ) continue;

				if( "yt_type" in m && m.yt_type == 'ffmpeg' ){
					this.createFullHD( menu, m );
				}
				else {
					this.createVideo( menu, m );
				}
			}

			this.createSetLi( menu, 'formats' );
			this.createSetLi( menu, 'folder' );
			if (fvd_single.check_like_status( )) this.createSetLi( menu, 'rating' );
			this.createSetLi( menu, 'wallpapers' );
			this.createSetLi( menu, 'nimbus' );
			this.createSetLi( menu, 'note_taking' );

		}

		// -------------------------------------------------------------------------------------------
		this.createVideo = function( menu, media )  {

			var imageUrl = "";
			if( "ext" in media ) imageUrl = fvd_single_Formats.getAccessibleImage( media.ext );

			var li = doc.createElement("li");
			var span = doc.createElement( "span" );
			span.setAttribute( "class", "yt-uix-button-menu-item" );

			var img = doc.createElement("img");
			img.setAttribute("align","left");
			img.setAttribute("style","margin-top: 5px");
			img.setAttribute("src", imageUrl);
			span.appendChild(img);

			var span_t = doc.createElement("span");
			span_t.setAttribute( "style", "margin-left: 10px;" );
			span_t.textContent = media.dn + " " + media.ext;
			span.appendChild(span_t);

			(function( medToDownload, span ){
						span.addEventListener("click", function(){
										try
										{
											fvd_single.downloadInstance.downloadByWindow(
															("yt_hash" in medToDownload && medToDownload.yt_hash ? medToDownload.yt_hash : fvd_single_Misc.md5( medToDownload.url )),
															medToDownload.url,
															medToDownload.download_name ? medToDownload.download_name : medToDownload.file_title,
															"." + medToDownload.ext,
															medToDownload.root_url,
															medToDownload.referer,
															function( downloadId ){	}
														);
										}
										catch( ex )
										{
											dump( "YT_BUTTON: ERROR WHILE START DOWNLOAD: " + ex + "\n" );
										}
									}, true);
					})( media, span );

			li.appendChild( span );

			menu.appendChild( li );

		}
		// -------------------------------------------------------------------------------------------
		this.createFullHD = function( menu, media )  {

			var doc = gBrowser.selectedBrowser.contentDocument;

			var li = doc.createElement("li");
			var span = doc.createElement( "span" );
			span.setAttribute( "class", "yt-uix-button-menu-item" );

			var imageUrl = "";
			if( "raw_file_ext" in media )	imageUrl = fvd_single_Formats.getAccessibleImage( media.raw_file_ext );
			else if( "ext" in media )	imageUrl = fvd_single_Formats.getAccessibleImage( media.ext );


			var img = doc.createElement("img");
			img.setAttribute("align","left");
			img.setAttribute("style","margin-top: 5px");
			img.setAttribute("src", imageUrl);
			span.appendChild(img);

			var span_t = doc.createElement("span");
			span_t.setAttribute( "style", "margin-left: 10px;" );
			span_t.textContent = media.dn + " " + media.ext;
			span.appendChild(span_t);
			span.addEventListener("click", function( event ){

													self.download_FullHD(
																		media.yt_hash,
																		media.yt_id,
																		media.url,
																		media.ext_url,
																		media.download_name ? media.download_name : media.file_title,
																		"." + media.ext,
																		media.root_url,
																		media.referer,
																		function( downloadId ){	}
																	);
											});

			li.appendChild( span );
			menu.appendChild( li );
		}

		// -------------------------------------------------------------------------------------------
		this.download_FullHD = function( yt_hash, yt_id, video_url, audio_url, name, ext,root_url, referer  )  {

			try
			{
				fvd_single.downloadInstance.downloadByWindowFullHD( yt_hash, yt_id, video_url, audio_url, name, ext, root_url, referer,
																		function( id_video, id_audio, dir_path, file_name, file_ext ) {

																			if( id_video ) {

																				var ff = fvd_single.downloadFullHD;
																				ff.push({ 	url: video_url,
																						video_id: id_video,
																						audio_id: id_audio,
																						video_state: false,
																						audio_state: false,
																						name: name,
																						path: dir_path,
																						file: file_name,
																						ext: file_ext
																					});
																			}
																		});
			}
			catch( ex )
			{
				dump( "YT_BUTTON: ERROR WHILE START DOWNLOAD: " + ex + "\n" );
			}

		}

		// -------------------------------------------------------------------------------------------
		this.createSetLi = function( menu, type )  {

			var doc = gBrowser.selectedBrowser.contentDocument;

			var li = doc.createElement("li");
			var span = doc.createElement( "span" );
			span.setAttribute( "class", "yt-uix-button-menu-item" );

			if (type == 'formats')
			{
				var imageUrl = fvd_single_Formats.getAccessibleImage("set");
				span.setAttribute( "style", "border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 1px;	border-bottom-width: 0px;  border-color: #999;" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("style","margin-top: 5px");
				img.setAttribute("src", imageUrl);
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;" );
				span_t.textContent = this.BUTTON_FORMATS_TITLE;
				span.appendChild(span_t);


				(function( span ){
							span.addEventListener("click", function( event ){
										//menu.setAttribute("style","display:none");
										fvd_single.set_file_types( event );
									}, true);
						})( span );
			}
			else if (type == 'folder')
			{
				var imageUrl = fvd_single_Formats.getAccessibleImage("set");
				span.setAttribute( "style", "border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 0px;	border-bottom-width: 0px;  border-color: #999;" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("style","margin-top: 5px");
				img.setAttribute("src", imageUrl);
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;" );
				span_t.textContent = this.BUTTON_FOLDER_TITLE;
				span.appendChild(span_t);

				(function( span ){
							span.addEventListener("click", function( event ){
										fvd_single.set_default_folder( event );
									}, true);
						})( span );
			}
			else if (type == 'rating')
			{
				var imageUrl = fvd_single_Formats.getAccessibleImage("like");
				span.setAttribute( "style", "border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 0px;	border-bottom-width: 0px;  border-color: #999;" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("style","margin-top: 5px");
				img.setAttribute("src", imageUrl);
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;" );
				span_t.textContent = this.BUTTON_RATING_TITLE;
				span.appendChild(span_t);


				(function( span ){
							span.addEventListener("click", function(){
										fvd_single.give_us_rating();
									}, true);
						})( span );
			}
			else if (type == 'betterfox')
			{
				var imageUrl = fvd_single_Formats.getAccessibleImage("bet");
				span.setAttribute( "style", "border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 0px;	border-bottom-width: 0px;  border-color: #999;" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("style","margin-top: 5px");
				img.setAttribute("src", imageUrl);
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;" );
				span_t.textContent = 'Make your Firefox 15% faster!';
				span.appendChild(span_t);

				(function( span ){
							span.addEventListener("click", function(){
										fvd_single.navigate_url( 'https://addons.mozilla.org/En-us/firefox/addon/betterfox/' );
									}, true);
						})( span );
			}
			else if (type == 'wallpapers')
			{
				var imageUrl = fvd_single_Formats.getAccessibleImage("wal");
				span.setAttribute( "style", "border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 0px;	border-bottom-width: 0px;  border-color: #999;" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("style","margin-top: 5px");
				img.setAttribute("src", imageUrl);
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;" );
				span_t.textContent = 'Live Wallpapers in your Browser!';
				span.appendChild(span_t);

				(function( span ){
							span.addEventListener("click", function(){
										fvd_single.navigate_url( 'https://addons.mozilla.org/firefox/addon/live-start-page-lst/' );
									}, true);
						})( span );
			}
			else if (type == 'nimbus')
			{
				var imageUrl = fvd_single_Formats.getAccessibleImage("nim");
				span.setAttribute( "style", "border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 0px;	border-bottom-width: 0px;  border-color: #999;" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("style","margin-top: 5px");
				img.setAttribute("src", imageUrl);
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;" );
				span_t.textContent = 'Make Screenshot, Edit, Upload';
				span.appendChild(span_t);

				(function( span ){
							span.addEventListener("click", function(){
										fvd_single.navigate_url( 'https://addons.mozilla.org/en-US/firefox/addon/nimbus-Screenshot/' );
									}, true);
						})( span );
			}
			else if (type == 'note_taking')
			{
				var imageUrl = fvd_single_Formats.getAccessibleImage("not");
				span.setAttribute( "style", "border: solid;	border-right-width: 0px;	border-left-width: 0px;	border-top-width: 0px;	border-bottom-width: 0px;  border-color: #999;" );

				var img = doc.createElement("img");
				img.setAttribute("align","left");
				img.setAttribute("style","margin-top: 5px");
				img.setAttribute("src", imageUrl);
				span.appendChild(img);

				var span_t = doc.createElement("span");
				span_t.setAttribute( "style", "margin-left: 10px;" );
				span_t.textContent = this.NOTE_TAKING_MENU_TITLE;
				span.appendChild(span_t);

				(function( span ){
							span.addEventListener("click", function(event){
										fvd_single.goto_site(event, 'note_taking');
									}, true);
						})( span );
			}
			li.appendChild( span );
			menu.appendChild( li );
		}


// ================================================================================================
	}
})();

