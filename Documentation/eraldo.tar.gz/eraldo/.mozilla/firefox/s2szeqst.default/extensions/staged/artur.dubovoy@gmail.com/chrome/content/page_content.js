

addEventListener("load", function(event) {
	var document = event.originalTarget;
	if (document.nodeName != "#document") {
		return;
	}
	var window = document.defaultView;

	if(window.top != window.self) {
		// no frames
		return;
	}
	if(document.location.protocol != "http:" && document.location.protocol != "https:") {
		// work only with websites
		return;
	}

	//dump("LOADEEDD CS: " + document.location.href + "\n");

	var spec = "/html/head/title";
	var title = null;
	try {
		title = document.evaluate(spec, document, null, 2, null).stringValue;
	} catch(ex) {  }
	if(title) {
		try {
			var re = new RegExp(spec.regexp || ".*","g");
			var match = re.exec(title.trim().replace(/\s+/g,' '));
			if(match) {
				if(match[1])
					title = match[1];
				else
					title = match[0];
				if(title.length==0)
					title = null;
			} else
				title = null;
		} catch(e) {
			title = null;
		}
	}
	if(title) {
		sendAsyncMessage("fvd.single:got-title", {
			url: document.location.href,
			title: title,
		});
	}


}, true );

