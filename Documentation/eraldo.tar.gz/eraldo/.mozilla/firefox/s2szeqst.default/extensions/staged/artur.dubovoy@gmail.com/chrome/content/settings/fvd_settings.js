function FVD_Settings() {
	const EXTENSION_GUID = 'artur.dubovoy@gmail.com';
	const SETTINGS_KEY_BRANCH = 'extensions.fvd_single.';

	var self = this;
	this.registry = null;

	var prefsGlobal = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);

	this.init = function()	{

		this.registry = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefService).getBranch(SETTINGS_KEY_BRANCH);
		var url = this.registry.getCharPref("options_page");

		var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator);
		var mainWindow = wm.getMostRecentWindow("navigator:browser");
		var browser = mainWindow.getBrowser();

		var q = '';
		if ('arguments' in window)	{
			var args = window.arguments[0].wrappedJSObject;
			q = '?tab='+args.path;
		}


		var found = false;
		for( var i = 0; i != browser.tabs.length; i++ ){
			var tab = browser.tabs[i];
			var brow = browser.getBrowserForTab( tab );

			var hh = brow.currentURI.spec;
			var k = hh.indexOf('?');
			if ( k != -1 )  hh = hh.substring(0, k);

			if( hh == url ){
				found = true;
				browser.selectedTab = browser.tabContainer.childNodes[i];
				break;
			}
		}

		if (!found) {
			var tab = browser.addTab(url+q);
			if (tab) browser.selectedTab = tab;
		}

		window.close();
	};


	window.addEventListener('load', function () {self.init.call(self)}, false);
};

var fvds = new FVD_Settings();