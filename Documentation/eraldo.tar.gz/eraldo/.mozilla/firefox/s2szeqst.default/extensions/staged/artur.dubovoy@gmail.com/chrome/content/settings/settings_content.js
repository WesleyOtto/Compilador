/*
 * Settings in PAGE
 */

(function(){

	FVD_SINGLE_SETTINGS_CONTENT = function(  ){

		const EXTENSION_GUID = 'artur.dubovoy@gmail.com';

		var self = this;
		var bundle = null;
		var main_wnd = null;
		var folder = null;
		var ffmpeg_file = null;
		var instant_apply = false;
		var osString = null;

		var doc = null;

		var prefsGlobal = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);

		// -------------------------------------------------------------------------------------------
		this.init = function(  )	{

			osString = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULRuntime).OS;

			bundle = Components.classes['@mozilla.org/intl/stringbundle;1'].getService(Components.interfaces.nsIStringBundleService).createBundle('chrome://fvd.single/locale/fvd.single.settings.label');

			doc = gBrowser.selectedBrowser.contentDocument;

			var wm = Components.classes['@mozilla.org/appshell/window-mediator;1'].getService(Components.interfaces.nsIWindowMediator);
			main_wnd = wm.getMostRecentWindow('navigator:browser');

			message();

			load();

			about();

			doc.getElementById('submitButton').addEventListener( "click", update, false);
			doc.getElementById('cancelButton').addEventListener( "click", cancel, false);

			doc.getElementById('masterMain').setAttribute('style', 'opacity: 1');

/* 			var ifr=doc.getElementById('ch_ad0-0');
			if (ifr) {
				var d=ifr.contentWindow||ifr.contentDocument;
				if (d.document) d=d.document;
				var elems = d.getElementById('ads').querySelectorAll('.resTitle');
				for (var i=0; i<elems.length; i++) {
					elems[i].querySelector('a').setAttribute('style', 'color: #5c5c6b');
				}
			}	 */
		}

		// -------------------------------------------------------------------------------------------
		function message() {
			var msgs = doc.querySelectorAll( "[msg]" );
			for (var i = 0; i != msgs.length; i++) 	{
				var sname = msgs[i].getAttribute('msg');
				try {
					var str = bundle.GetStringFromName( 'fvd.single.'+sname );
					msgs[i].textContent = str;
				}
				catch(e) {
					dump('\nERROR: '+e+'\n'+sname+'\n');
				}
			}
		}

		// -------------------------------------------------------------------------------------------
		function about() {
			var xai = Components.classes['@mozilla.org/xre/app-info;1'].getService(Components.interfaces.nsIXULAppInfo);
			var vc = Components.classes['@mozilla.org/xpcom/version-comparator;1'].getService(Components.interfaces.nsIVersionComparator);
			var elem = doc.getElementById('fvdsd_version_value');
			if (vc.compare(xai.platformVersion, '1.9.3') >= 0)	{
				// works via addon manager
				AddonManager.getAddonByID(EXTENSION_GUID, function(addon)	{
					if(elem) elem.textContent = addon.version;
					doc.title = addon.name;
					doc.getElementById('addon_name').textContent = addon.name + ' - Change Your Options';
				});
			} else	{
				try				{
					var ver = Components.classes['@mozilla.org/extensions/manager;1'].getService(Components.interfaces.nsIExtensionManager).getItemForID(EXTENSION_GUID).version;
					if(elem) elem.textContent = ver;
				} catch (e) {}
			}
		}

		// -------------------------------------------------------------------------------------------
		function load() {

			var options = doc.querySelectorAll( "[sname]" );
			for (var i = 0; i != options.length; i++) 	{
				var sname = options[i].getAttribute('sname');
				var type = options[i].getAttribute('type');
				try {
					var str;
					if (type == 'checkbox') {
						str = fvd_single.registry.getBoolPref(sname);
						options[i].checked = str;
					}
					else if (type == 'radio') {
						if (sname == 'download.custom') {
							str = fvd_single.registry.getBoolPref(sname);
							if ( (options[i].value == "true" ? true : false) == str ) options[i].checked = true;
						}
						else {
							str = fvd_single.registry.getCharPref(sname);
							if (options[i].value == str) options[i].checked = true;
						}
					}
				}
				catch(e) {
					dump(e+'\n');
				}
				options[i].addEventListener( "change", changeOption, false);
			}
			var be = doc.getElementById('fvdsd_main_button_exists');
			if (be) {
				be.checked = main_wnd.fvd_single.is_main_button_exists();
				be.addEventListener( "change", changeOption, false);
			}

			var fb = doc.getElementById('fvdsd_folder_browse');
			var dm_pref = doc.getElementById('fvdsd_general_download_mode');
			if (fb && dm_pref) fb.disabled = (!dm_pref.value);
			if (fb) fb.addEventListener( "click", folder_browse, false);

			try	{
				var str = fvd_single.registry.getComplexValue('download.folder', Components.interfaces.nsISupportsString);
				var file = Components.classes['@mozilla.org/file/local;1'].createInstance(Components.interfaces.nsILocalFile);
				file.initWithPath(str.data);
				if (file.exists() && file.isDirectory())	{
					folder = file;
					folder_setup();
				}

			} catch (e) {
				dump('ERROR: '+e+'\n');
			}

			if( osString.toLowerCase() != "linux" )	{
				doc.getElementById('fvdsd_ffmpeg_content').setAttribute('style', 'display: none');
			}
			else {
				var elem = doc.getElementById("fvdsd_ffmpeg_manual");
				if( prefsGlobal.getCharPref("general.useragent.locale").indexOf("ru") != -1 ){
					elem.setAttribute( "href", 'http://flashvideodownloader.org/ffmpeg/indexru.html' );
				}
				else {
					elem.setAttribute( "href", 'http://flashvideodownloader.org/ffmpeg/indexen.html' );
				}
			}


			var fb = doc.getElementById('fvdsd_ffmpeg_browse');
			if (fb) fb.addEventListener( "click", ffmpeg_file_browse, false);

			try		{
				var str = this.registry.getComplexValue('download.ffmpeg_file', Components.interfaces.nsISupportsString);
				var file = Components.classes['@mozilla.org/file/local;1'].createInstance(Components.interfaces.nsILocalFile);
				file.initWithPath(str.data);
				if (file.exists() && !file.isDirectory())	{
					ffmpeg_file = file;
					ffmpeg_file_setup();
				}

			} catch (e) {}
		}

		function ffmpeg_file_browse(event)	{
			var bundle = Components.classes['@mozilla.org/intl/stringbundle;1'].getService(Components.interfaces.nsIStringBundleService).createBundle('chrome://fvd.single/locale/fvd.single.settings.properties');
			var title = bundle.GetStringFromName('fvd.single.select_ffmpeg_file.title');

			var fp = Components.classes['@mozilla.org/filepicker;1'].createInstance(Components.interfaces.nsIFilePicker);
			fp.init(window, title, Components.interfaces.nsIFilePicker.modeOpen);

			if (fp.show() == Components.interfaces.nsIFilePicker.returnOK)	{
				ffmpeg_file = fp.file;
				ffmpeg_file_setup();

				var str = Components.classes['@mozilla.org/supports-string;1'].createInstance(Components.interfaces.nsISupportsString);
				str.data = ffmpeg_file.path;
				self.registry.setComplexValue('download.ffmpeg_file', Components.interfaces.nsISupportsString, str);

			}
		};

		function ffmpeg_file_setup()	{
			var ft = doc.getElementById('fvdsd_ffmpeg_file_text');
			if (ft && ffmpeg_file)	{
				ft.value = ffmpeg_file.leafName;

				var ios = Components.classes['@mozilla.org/network/io-service;1'].getService(Components.interfaces.nsIIOService);
				var fh = ios.getProtocolHandler('file').QueryInterface(Components.interfaces.nsIFileProtocolHandler);
			}
		};

		function folder_browse(event)	{
			var bundle = Components.classes['@mozilla.org/intl/stringbundle;1'].getService(Components.interfaces.nsIStringBundleService).createBundle('chrome://fvd.single/locale/fvd.single.settings.properties');
			var title = bundle.GetStringFromName('fvd.single.select_folder.title');

			var fp = Components.classes['@mozilla.org/filepicker;1'].createInstance(Components.interfaces.nsIFilePicker);
			fp.init(window, title, Components.interfaces.nsIFilePicker.modeGetFolder);
			if (folder != null) fp.displayDirectory = folder;
			if (fp.show() == Components.interfaces.nsIFilePicker.returnOK)	{
				folder = fp.file;
				folder_setup();

				if (instant_apply)		{
					try 	{
						var str = Components.classes['@mozilla.org/supports-string;1'].createInstance(Components.interfaces.nsISupportsString);
						str.data = folder.path;
						fvd_single.registry.setComplexValue('download.folder', Components.interfaces.nsISupportsString, str);

					} catch (e){}
				}
			}
		};

		function folder_setup()		{
			var ft = doc.getElementById('fvdsd_folder_text');
			if (ft && folder)		{
				ft.value = folder.leafName;
			}
		};

		// -------------------------------------------------------------------------------------------
		function changeOption(opt) {

			var bu = doc.getElementById('submitButton');
			if (bu) bu.removeAttribute( "disabled");

		}

		// -------------------------------------------------------------------------------------------
		function update() {

			var be = doc.getElementById('fvdsd_main_button_exists');
			if (be)	{
				var observer = Components.classes['@mozilla.org/observer-service;1'].getService(Components.interfaces.nsIObserverService);
				observer.notifyObservers(null, 'FVD.Single-MainButton-Change', (be.checked == true));
			}
			var bed = doc.getElementById('fvdsd_button_enable_drug');
			if (bed) {
				//observer.notifyObservers(null, 'FVD.Single-Sovetnik-Change', bed.checked.toString());
			}

			var options = doc.querySelectorAll( "[sname]" );
			for (var i = 0; i != options.length; i++) 	{
				var sname = options[i].getAttribute('sname');
				var type = options[i].getAttribute('type');
				try {
					if (type == 'checkbox') {
						fvd_single.registry.setBoolPref(sname, options[i].checked);
					}
					else if (type == 'radio') {
						if (sname == 'download.custom') {
							if (options[i].checked) {
								fvd_single.registry.setBoolPref(sname, (options[i].value == "true" ? true : false));
							}
						}
						else {
							if (options[i].checked) {
								fvd_single.registry.setCharPref(sname, options[i].value);
							}
						}
					}
				}
				catch(e) {
					dump(e+'\n');
				}
			}

			if (folder != null)	{
				try	{
					var str = Components.classes['@mozilla.org/supports-string;1'].createInstance(Components.interfaces.nsISupportsString);
					str.data = folder.path;
					fvd_single.registry.setComplexValue('download.folder', Components.interfaces.nsISupportsString, str);

				} catch (e){}
			}

			cancel();
		}

		// -------------------------------------------------------------------------------------------
		function cancel() {
			var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator);
			var mainWindow = wm.getMostRecentWindow("navigator:browser");
			var browser = mainWindow.getBrowser();
			browser.removeCurrentTab();
		}

// ================================================================================================
	}
})();

