const nsISupports = Components.interfaces.nsISupports;
const CLASS_ID = Components.ID('{213bea84-5789-4ff2-a3da-24ea819eb505}');
const CLASS_NAME = 'FVD media sniffer';
const CONTRACT_ID = '@flashvideodownloader.org/single_media_sniffer;1';

Components.utils.import("resource://fvd.single.modules/async.js");
Components.utils.import("resource://fvd.single.modules/misc.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdTwitch.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdMediaStream.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdDailyMotion.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdYouTube.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdVKontakte.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdFaceBook.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdBreakCom.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdUtils.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdFormats.js");

const TITLE_MAX_LENGTH = 96;

const SETTINGS_KEY_BRANCH = 'extensions.fvd_single.';

const IGNORE_SNIFFER_URL_SIGNS = [
	"soloset.net",
	"solosing.com",
	"canalrcn.com",
	"canalrcnmsn.com",
	"noticiasrcn.com",
	"headbar.net",
	"periscope.tv"
];

const triggerVideoSize = 1048576;
const minFileSizeToCheck = 20 * 1024;	// 20kb

var xulRuntime = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULRuntime);
var userOS = xulRuntime.OS;

var KeyValueStore = new function(){

	var items = {};

	var event = {
		observe: function(subject, topic, data) {

			var now = new Date().getTime();

			var toRemove = [];
			for( var k in items ){
				if( items[k].expires && items[k].expires <= now ){
					toRemove.push( k );
				}
			}

			toRemove.forEach( function(){
				delete items[k];
			} );

		}
	};
	var timer = Components.classes["@mozilla.org/timer;1"].createInstance(Components.interfaces.nsITimer);

	timer.init(event, 60*1000, Components.interfaces.nsITimer.TYPE_REPEATING_PRECISE_CAN_SKIP);

	this.set = function( key, value, ttl ){

		var now = new Date().getTime();

		var expires = now + ttl;
		if( !ttl ){
			expires = 0;
		}

		items[key] = {
			value: value,
			expires: expires
		};

	};

	this.get = function( key ) {

		if( typeof items[key] != "undefined" ){
			return items[key].value;
		}

		return null;

	};

};

// -----------------------------------------------------
function MediaPrepare( data ){

	if (data.url.indexOf("#") != -1)  data.url = data.url.substring(0,data.url.indexOf("#"));
	// dailymotion.com
	var lurl = data.url.toLowerCase();
	if( ( lurl.indexOf( "dailymotion.com" ) != -1 || lurl.indexOf( ".dmcdn.net" ) != -1 ) && lurl.indexOf( "/frag(" ) != -1 )
	{
		// remove fragment data from url
		data.url = data.url.replace( /\/frag\(.?\)/, "" );
		data.size = null;

		if (!data.name)
		{

			var url = data.url;
			var tmp = url.split( "?" );
			url = tmp[0];
			tmp = url.split( "/" );
			tmp = tmp[ tmp.length - 1 ];

			data.name = tmp;

		}
		return data;
	}
	return null;
}

// -----------------------------------------------------
function FVD_Media_Sniffer()   {

	this.Observe_Media_Detect			= 'FVD.Single-Media-Detect';
	this.Observe_Media_DailyMotion		= 'FVD.Single-Media-DailyMotion';
	this.Observe_Media_Youtube			= 'FVD.Single-Media-Youtube';
	this.Observe_Media_VKontakteAudio	= 'FVD.Single-Media-VKontakteAudio';
	this.Observe_Media_VKontakteVideo	= 'FVD.Single-Media-VKontakteVideo';

	var self = this;
	this.detector = null;
	this.observer = null;
	this.files = {};
	this.media_pages = {};
	this.media = {};

	this.twitch_m3u8 = {};

	this.debug = false;

	this.timers = []; // timers for youtube

	this.allowYoutube = true;
	this.silentMode	= false;

	// ---------------------------------------------------------------------------------
    this.getBrowserFromChannel = function(aChannel){
      try {
      	var notificationCallbacks;
      	if(aChannel.loadGroup && aChannel.loadGroup.notificationCallbacks) {
      		notificationCallbacks = aChannel.loadGroup.notificationCallbacks;
      	}
      	else {
      		notificationCallbacks = aChannel.notificationCallbacks;
      	}
        if (!notificationCallbacks) {
					return null;
        }
				var domWin = notificationCallbacks.getInterface(Components.interfaces.nsIDOMWindow);

				var  gBrowser   = domWin.QueryInterface(Components.interfaces.nsIInterfaceRequestor)
		                       .getInterface(Components.interfaces.nsIWebNavigation)
		                       .QueryInterface(Components.interfaces.nsIDocShellTreeItem)
		                       .rootTreeItem
		                       .QueryInterface(Components.interfaces.nsIInterfaceRequestor)
		                       .getInterface(Components.interfaces.nsIDOMWindow);

				var gBrowser = mainWindow.gBrowser;

        return gBrowser.getBrowserForDocument(domWin.top.document);
      }
      catch (e) {
      	dump("Fail to get browser: " + e + "\n");
        return null;
      }
    };

	// ---------------------------------------------------------------------------------------------- listeners

	this.browser_progress_listener = {
		onLocationChange: function(aWebProgress, aRequest, aURI){
			//fvd_single_VKontakte.checkVkontakteAudio( aWebProgress.DOMWindow.document, self );
		}
	};

	// ----------------------------------------------------------------------------------------------
	this.pageLoadListener = function( event ){
		//fvd_single_VKontakte.checkVkontakteAudio( event.target, self );
	};

	// ----------------------------------------------------------------------------------------------
	this.observer_struct = {observe : function(aSubject, aTopic, aData)
	{
		if (self.silentMode) return;

		switch (aTopic)
		{
			case 'http-on-examine-cached-response':
			case 'http-on-examine-response':
			{

				try	{
					aSubject.QueryInterface(Components.interfaces.nsIHttpChannel);
				} catch (e){
					dump("ERROR " + e + "\r\n");
				}

				try		{
					var _httpChannel = aSubject.QueryInterface(Components.interfaces.nsIHttpChannel);
					if( _httpChannel.getRequestHeader("X-FVD-Extra") )		break;
				}
				catch( ex ){
				}

				var wnd = null, doc = null, url = null, root_url = null, title = "";

				try		{
					wnd = fvd_single_Utils.parent_window( aSubject );
					if (!wnd) break;
					doc = wnd.document;
					if (!doc) break;
					root_url = fvd_single_Utils.root_document_url(aSubject);
					url = aSubject.QueryInterface(Components.interfaces.nsIChannel).URI.spec;

					if(userOS == "Android") {
						// fennec only
						if(root_url == "about:blank") {
							root_url = "";
						}
						if(!root_url) {
							// use same url as file for root_url
							root_url = url;
						}
					}
					else {
						if (root_url == 'about:blank' || root_url == null)  root_url = url;
					}
				}
				catch( ex )	{
					dump( "Exception root_url: " + ex +'\n' );
				}

				if (!url || !root_url) break;

				var httpChannel	= {	subject: 	aSubject,
									wnd:	 	wnd,
									url:	 	url,
									root_url:	root_url,
								  }

				getTitle(httpChannel, function(tt) {

					httpChannel.title = tt;

					workerSniffer(httpChannel);

				});

				break;
			}

			case 'nsPref:changed':
			{
				switch (aData)
				{
					case 'news.update_interval':
					{
						self.news_update_interval = self.registry.getIntPref(aData);
						break;
					}
					break;
				}
			}
		}
	}};

	// --------------------------------------------
	var pageTitle = {};

	function getTitle(httpChannel, callback) 	{

		var wnd,
			title = "",
			root_url = httpChannel.root_url,
			hash = fvd_single_Misc.md5(root_url);

		if (pageTitle[hash]) {
			callback( pageTitle[hash] );
		}
		else {
			pageTitle[hash] = _get();
/* 			var globalMM = Components.classes["@mozilla.org/globalmessagemanager;1"].getService(Components.interfaces.nsIMessageListenerManager);
			globalMM.loadFrameScript( "chrome://fvd.single/content/page_content.js", true );
			globalMM.addMessageListener("fvd.single:got-title", function( message ){
				var url = message.data.url;
				pageTitle[fvd_single_Misc.md5(url)] = message.data.title;
				callback(message.data.title);
			}); */
			callback( pageTitle[hash] );
		}

		function _get() {

			if ( httpChannel.wnd ) wnd = httpChannel.wnd;
			else  wnd = fvd_single_Utils.parent_window(httpChannel.subject);

			var title = '_';
			try {
				if (wnd != null)	{
					var ogt = (wnd.document.evaluate('/html/head/meta[@property="og:title"]', wnd.document.documentElement, null, 9, null)).singleNodeValue; // 9 - XPathResult.FIRST_ORDERED_NODE_TYPE
					if (ogt != null)	{
						title = ogt.getAttribute('content');
					}
					else {
						title = wnd.document.title;
					}
				}
			} catch (e) {}

			return title;
		}

	}

	// --------------------------------------------
	function workerSniffer(httpChannel) 	{

		if( self.allowYoutube )	{
			fvd_single_YouTube.save_channel( httpChannel, self );
			fvd_single_YouTube.save_page( httpChannel, self );
			fvd_single_YouTube.save_embeds( httpChannel, self );
		}
		else	{
			var url = httpChannel.url;

			if( url.indexOf("://s.ytimg.com") != -1 ||
				url.indexOf("://o-o.preferred.") != -1 ||
				url.indexOf("youtube.com") != -1 )	{
				return;
			}
		}

		if (fvd_single_VKontakte.save( httpChannel, self )) return;

		if (fvd_single_DailyMotion.save( httpChannel, self )) return;

		if (fvd_single_Twitch.save( httpChannel, self )) return;

		if (fvd_single_MediaStream.save( httpChannel, self )) return;

		if (fvd_single_FaceBook.save( httpChannel, self )) return;

		if (fvd_single_BreakCom.save( httpChannel, self )) return;

 		// all successed GET responces
		if ((httpChannel.subject.requestMethod == 'GET') && (httpChannel.subject.responseStatus < 400))	{
			// check for video and audio types
			if (self.needed_media(httpChannel))	{
				self.save_link(httpChannel);
			}
		}

	}

	// --------------------------------------------
	this.needed_media = function(httpChannel) 	{

		var url = httpChannel.url;

		// игнорируем
		if (url.indexOf("#") != -1)  url = url.substring(0, url.indexOf("#"));

		// youtube & vk
		if( url.indexOf("://s.ytimg.com") != -1 ||
		    url.indexOf("://o-o.preferred.") != -1 ||
		    url.indexOf("youtube.com") != -1 ) {
						return false;
		}

		if( url.indexOf( "vk.com" ) != -1  ) return false;

		var ignore = false;
		IGNORE_SNIFFER_URL_SIGNS.forEach(function( sign ){
			if( url.indexOf( sign ) != -1 ){
				ignore = true;
				return false;
			}
		});
		if( ignore )			return;

		// if scheme is chrome - ignore this video
		if( httpChannel.subject.QueryInterface(Components.interfaces.nsIChannel).URI.scheme == "chrome" )	{
			return false;
		}

		// check min size
		try	{
			var contentLength = httpChannel.subject.getResponseHeader('Content-Length');
			if( contentLength )	{
				if( contentLength < minFileSizeToCheck )	return false;
				if( contentLength >= triggerVideoSize )		return true;
			}
		}
		catch(e){
			return false; // fail check media length
		}

		var ext = fvd_single_Utils._get_file_ext( url );

		if( fvd_single_Utils._is_ignored_ext( ext ) )  {
			return false;
		}

		// check Location header, if set, no handle this url
		try		{
			var ct = httpChannel.subject.getResponseHeader('Location');
			if( ct ){
				return false;
			}

		} catch (e) {}

		// check extension
		if( fvd_single_Utils._is_video_ext( ext ) )		return true;

		if( fvd_single_Utils._is_game_ext( ext ) )		return true;

		// check disposition extension
		try	{
			var dn = fvd_single_Utils.disposition_name(httpChannel.subject);
			var ext = fvd_single_Utils._get_file_ext( dn );

			if( fvd_single_Utils._is_video_ext( ext ) || fvd_single_Utils._is_game_ext( ext ) )		return true;

		}
		catch (e) {		}

		return false;

	}

	// --------------------------------------------------------------------------
	this.save_link = function(httpChannel)	{

		var dn ='',
			dt = httpChannel.title,
			url = httpChannel.url,
		    root_url = httpChannel.root_url;

		if (url.indexOf("#") != -1)  url = url.substring(0, url.indexOf("#"));

		if(userOS == "Android") {
			// fennec only
			if(root_url == "about:blank") {
				root_url = "";
			}
			if(!root_url) {
				// use same url as file for root_url
				root_url = url;
			}
		}

		// get ext from content-type
		var ext = fvd_single_Utils._get_ext_from_content_type( httpChannel.subject );
		try	{
			dn = fvd_single_Utils.disposition_name(httpChannel.subject);
		} catch (e) {}

		try	{
			if (dn) {
				var exs = dn.match(/([^\.]+)$/i);
				if ((exs != null) && (exs[1] != dn))
				{
					if( !ext ){
						ext = exs[1].toLowerCase();
					}
					dn = dn.substr(0, dn.length - ext.length - 1);
				}
			}
			else{
				if( !ext ){
					ext = fvd_single_Utils._get_file_ext(httpChannel.subject.QueryInterface(Components.interfaces.nsIChannel).URI.spec);
				}
			}

			if (!ext) ext = fvd_single_Utils.parent_document_ext(httpChannel.subject);

		} catch (e) {}


		var nameFromChannel = fvd_single_Utils._extract_file_name_from_channel(httpChannel.subject);
		var size = null;
		try{
			var size = 	httpChannel.subject.getResponseHeader( "Content-Length" );
		}
		catch(ex){}

		if( ext && ext.toLowerCase() == "swf" ){
			if(!fvd_single_Formats.getSwfDisplayState()){
				return false; // not add swf
			}
		}

		if( root_url.indexOf("chrome://") != -1 )
		{
			return false;//ignore chrome
		}

		var contentType = null;
		try
		{
			contentType = httpChannel.subject.getResponseHeader( "Content-Type" );
		}
		catch( ex )	{	}


		var referer = null;
		try
		{
			referer = httpChannel.subject.getRequestHeader( "Referer" );
		}
		catch( ex ){	}

		if(this.has_typed_media_for_url(root_url)) {
			return;
		}

		// url preparations step dailymotion
		var file_item = {
			"display_name": nameFromChannel ? nameFromChannel : url,
			"download_name" : nameFromChannel,
			'dn' : dn,
			'pn' : dt,
			'url': url,
			'ext': fvd_single_Utils._is_video_ext(ext) ? ext : null,
			'raw_file_ext': ext,
			'root_url' : root_url,
			'time' : (new Date()).toUTCString(),
			"playable": fvd_single_Utils.isPlayable(ext, contentType),
			'direct': true,
			referer: referer
		};

		if( size ) {
			file_item.size = size;
		}
		var hash = fvd_single_Misc.md5(url + root_url);
		this.files[hash] = file_item;

		this.media_pages[root_url] = url;

		if (this.observer != null) {
		  this.observer.notifyObservers(null, 'FVD.Single-Media-Detect', root_url);
		  if(userOS == "Android") {
		    this.observer.notifyObservers(null, 'FVD.Single-Media-Detect', url);
		  }
		}

	};

 	this.getSizeByUrl = function( url, callback ){

		var cached = KeyValueStore.get( "sizefor:"+url );
		if( cached ){
			var event = {
				notify: function(timer) {
					callback( url, cached );
				}
			};

			// Now it is time to create the timer...
			var timer = Components.classes["@mozilla.org/timer;1"].createInstance(Components.interfaces.nsITimer);
			timer.initWithCallback(event, 100, Components.interfaces.nsITimer.TYPE_ONE_SHOT);

			return;
		}

		function _setToCache( size ){
			KeyValueStore.set( "sizefor:"+url, size, 5 * 60 * 1000 );
		}

        var ajax = Components.classes["@mozilla.org/xmlextras/xmlhttprequest;1"].createInstance(Components.interfaces.nsIXMLHttpRequest);
		ajax.open('GET', url, true);
		ajax.setRequestHeader('Cache-Control', 'no-cache');
		ajax.channel.loadFlags |= Components.interfaces.nsIRequest.LOAD_BYPASS_CACHE;
		ajax.url = url;

		ajax.onreadystatechange = function(){
						if( this.readyState == 3 )	{
							var size = this.getResponseHeader("Content-Length");
							if (this.status == 200) {
								if( size )	{
									_setToCache( size );
									callback( this.url, size );
									this.abort();
								}
							}
						}

						if (this.readyState == 4) 	{
							if (this.status == 200)   {
								var size = null;
								try		{
									size = this.getResponseHeader("Content-Length");
								}
								catch(ex){}

								_setToCache( size );
								callback( this.url, size );
							}
							else	{
								callback( this.url, null );
							}
						}

					};

		ajax.send( null );
	};

	this.has_typed_media_for_url = function(page_url) {
		var files = this.get_files(page_url);
		if(!files) {
			return false;
		}
		for(var k in files) {
			if(files[k].yt_type) {
				return true;
			}
		}
		return false;
	};

	// ------------------------
	this.remove_files_by_page_url = function( page_url ){
		var countRemoved = 0;

		for (var i in this.files)
		{
			if (this.files[i]['root_url'] == page_url)	{
				delete this.files[i];
				countRemoved++;
			}
		}

		if( typeof this.media_pages[page_url] != "undefined" )
		{
			delete this.media_pages[page_url];
		}


		//dump( "Total files count: " + Object.keys(this.files).length + "\n\n" );

		// события в обработчики
		fvd_single_FaceBook.removeUrl( page_url );

		return countRemoved;
	};

	this.get_files = function(url)
	{
		var f = {};

		for (var i in this.files)
		{
			if (this.files[i]['root_url'] == url) f[i] = this.files[i];
		}

		return f;
	};

	this.get_files_all = function(  ){
		var media = {};

		for( var i in this.files ){
			var file = this.files[i];

			if( !file.root_url ){
				continue;
			}

			if( !( file.root_url in media ) ){
				media[file.root_url] = {};
			}
			media[file.root_url][i] = file;
		}

		// clone object before return
		return JSON.parse( JSON.stringify( media ) );
	};

	this.get_files_url = function( url ){
		var media = {};

		for( var i in this.files )
		{
			var file = this.files[i];

			if( !file.root_url )	continue;

			if (this.fileroot_url == url)
			{
				if( !( file.root_url in media ) )		media[file.root_url] = {};
				media[file.root_url][i] = file;
			}
		}
		return media;
	};

	// ----------------------------------------------------------------------------------
	this.is_insert_button = function( type )	{

		var branch = this.registry.getBranch(SETTINGS_KEY_BRANCH);
		try 	{
			return branch.getBoolPref('display_'+type+'_button');

		} catch (e){		}

		return false;
	};

	this.has_media = function(url)
	{
		if (url in this.media_pages)
		{
			return true;
		}
		return false;
	};

	try
	{
		this.detector = Components.classes['@flashvideodownloader.org/single_site_detector;1'].getService(Components.interfaces.IFVDSingleDetector);

		this.observer = Components.classes['@mozilla.org/observer-service;1'].getService(Components.interfaces.nsIObserverService);
		this.observer.addObserver(this.observer_struct, 'http-on-examine-response', false);
		this.observer.addObserver(this.observer_struct, 'http-on-examine-cached-response', false);

		this.registry = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefService);

		var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator);
		var mainWindow = wm.getMostRecentWindow("navigator:browser");

		try
		{
			mainWindow.document.getElementById( "appcontent" ).addEventListener("DOMContentLoaded", function( event ){
				self.pageLoadListener( event );
			}, true);
			mainWindow.gBrowser.addProgressListener(this.browser_progress_listener);
		}
		catch(ex){
			dump( "!!! FAIL SET document appcontent listener " + ex + "\n" );
		}


    } catch (e) {

		dump( "!!! FAIL INIT SNIFFER " + e + "\n" );

	};

	this.wrappedJSObject = this;
};

var _snifferInstance = new FVD_Media_Sniffer();

// -----------------------------------------------------
// class factory
var FVD_Media_Sniffer_Factory =
{
	createInstance: function (aOuter, aIID)
	{
		if (aOuter != null) throw Components.results.NS_ERROR_NO_AGGREGATION;
		return _snifferInstance;
	}
};

// Moduel definition
var FVD_Media_Sniffer_Module =
{
	registerSelf: function(aCompMgr, aFileSpec, aLocation, aType)
	{
		aCompMgr = aCompMgr.QueryInterface(Components.interfaces.nsIComponentRegistrar);
		aCompMgr.registerFactoryLocation(CLASS_ID, CLASS_NAME, CONTRACT_ID, aFileSpec, aLocation, aType);
	},

	unregisterSelf: function(aCompMgr, aLocation, aType)
	{
		aCompMgr = aCompMgr.QueryInterface(Components.interfaces.nsIComponentRegistrar);
		aCompMgr.unregisterFactoryLocation(CLASS_ID, aLocation);
	},

	getClassObject: function(aCompMgr, aCID, aIID)
	{
		if (!aIID.equals(Components.interfaces.nsIFactory)) throw Components.results.NS_ERROR_NOT_IMPLEMENTED;
		if (aCID.equals(CLASS_ID)) return FVD_Media_Sniffer_Factory;

		throw Components.results.NS_ERROR_NO_INTERFACE;
	},

	canUnload: function(aCompMgr)
	{
		return true;
	}
};

// Module initialization
function NSGetModule(aCompMgr, aFileSpec)
{
	return FVD_Media_Sniffer_Module;
};


function NSGetFactory()
{
	return FVD_Media_Sniffer_Factory;
};



