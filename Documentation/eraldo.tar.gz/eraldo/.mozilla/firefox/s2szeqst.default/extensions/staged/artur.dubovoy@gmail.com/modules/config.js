
var EXPORTED_SYMBOLS = ["fvd_single_Config"];

var fvd_single_Config = new function(){
	this.extID = 'artur.dubovoy@gmail.com';
};
