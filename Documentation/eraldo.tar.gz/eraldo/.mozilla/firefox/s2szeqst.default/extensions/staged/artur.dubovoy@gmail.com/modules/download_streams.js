var EXPORTED_SYMBOLS = ["fvd_single_DownloadStreams"];

Components.utils.import("resource://fvd.single.modules/async.js");
Components.utils.import("resource://fvd.single.modules/misc.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdUtils.js");

try{
	Components.utils.import("resource://gre/modules/FileUtils.jsm");
}
catch( ex ){
	dump('ERROR: modules: '+ex+'\n');
}

try{
	var dm = Components.classes["@mozilla.org/download-manager;1"].getService(Components.interfaces.nsIDownloadManager);
}
catch( ex ){
	dump('ERROR: download-manager: '+ex+'\n');
}

var useNewStyle = false;
var appInfo = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULAppInfo);
var osString = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULRuntime).OS;
var DIRECTORY_SEPARATOR = osString == "WINNT" ? "\\" : "/";
var majorV = appInfo.version.split(".")[0];
var browserName = appInfo.name.toLowerCase().replace(/\s/g,'');

if(osString == "Android") {
	if(majorV >= 37) {
		useNewStyle = true;
	}
}
else if ( browserName == 'palemoon' ) {
	useNewStyle = false;
}
else if(majorV >= 26) {
	useNewStyle = true;
}

if ( useNewStyle ) {
	try{
		Components.utils.import("resource://gre/modules/Downloads.jsm");
	}
	catch( ex ){
		dump('ERROR: downloads: '+ex+'\n');
	}
}

if (typeof fvd_single_DownloadStreams == "undefined") {

	var fvd_single_DownloadStreams = new function(){

		var self = this;

		var video = {};

		const DLBS_NORMAL = 0;
		const DLBS_DOWNLOADING = 1;
		const DLBS_START = 5;
		const DLBS_STOP = 6;
		const DLBS_FINALIZY = 7;
		const DLBS_FINISH = 8;

		const STREAM_WORKING = 0
		const STREAM_START_DOWNLOAD = 1;
		const STREAM_PREPARING = 10;
		const STREAM_SAVING = 11;
		const STREAM_FINALIZING = 15;
		const STREAM_FINISHING = 99;

		const MAX_STREAM_DOWNLOAD = 10;
		const MIN_STREAM_DOWNLOAD = 3;

		var funcStreamState = [];

		var oldStyleListeners = [];

		var _lastRecordId = 0;

		function _nextRecordId(){
			_lastRecordId++;

			return _lastRecordId;
		}


		// -------------------------------------------------------------------------------------------------------
		this.getVideoForId = function( id ) {

			for (var urlHash in video) {

				for (var i=0; i<video[urlHash].file.length; i++) {

					if (video[urlHash].file[i].id == id)  return video[urlHash].file[i];
				}
			}

			return null;
		};

		// -------------------------------------------------------------------------------------------------------
		this.statusPage = function( root_url, callback ) {

			for (var urlHash in video) {
				if (video[urlHash].root_url == root_url) {
					return callback(true);
				}
			}

		};

		// -------------------------------------------------------------------------------------------------------
		this.isVideo = function( urlHash ) {

			if (video[urlHash] && !video[urlHash].stop) 	return true;

			return false;
		};

		// -------------------------------------------------------------------------------------------------------
		this.getSize = function( urlHash ) {

			if (video[urlHash]) {
				try {
					var x = parseInt(video[urlHash].size);
					if (x) return prepareVideoSize(x);
					else return video[urlHash].size;
				}
				catch(ex) {
					return video[urlHash].size;
				}
			}

			return '';
		};

		var _oldStyleListener = function(){

		};

		_oldStyleListener.prototype = {

			view: {},

			onStateChange : function(prog, req, flags, status, dl)
			{
				var ff = self.getVideoForId( dl.id );
				if ( dl.state == Components.interfaces.nsIDownloadManager.DOWNLOAD_FINISHED ) {
					ff.load = true;
					ff.size = dl.targetFile.fileSize;
					var f = check_end_download(ff.hash);
					if (f)  finalizing_download(ff.hash);
				}
			},

		};

		// -------------------------------------------------------------------------------------------------------
		this.add_state = function( funcState ) {

			if( useNewStyle ){

				funcStreamState.unshift(funcState);

			}
			else {
				var listener = new _oldStyleListener();
				listener.view = funcState;

				oldStyleListeners.push( listener );

				dm.addListener( listener );

				funcStreamState.unshift(funcState);
			}

		};

		// -------------------------------------------------------------------------------------------------------
		this.remove_state = function( funcState ) {

			if (funcStreamState.length>0 && funcStreamState[0] == funcState) {

				funcStreamState.shift(funcState);
			}

		};

		// -------------------------------------------------------------------------------------------------------
		this.start = function(params, callback) 	{

			//fvd_single_Utils.log(params, ' download_Stream.start ');

			if ( typeof params.urllist == 'object' && params.urllist ) {

				var x = { 	host: 		host,
							url_m3u8:	params.playlist,
							url_hash:	params.hash,
							dir_path:	params.dirPath,
							file_path:	params.fileName,
							root_url:	params.rootUrl,
							referer:	params.referer,
							initSeg:	params.initSeg,
							size:		0,
							stop:		false,
							endlist:	false,
							file:		[],
							queue:		0,
							state:		STREAM_WORKING
						 };

				for (var i=0; i<params.urllist.length; i++) {

					x.file.push({	fileName: 	params.urllist[i],
									url:		params.playlist + params.urllist[i],
									id:			0,
									size:		0,
									hash:		params.hash,
									state:		0,
								});
				}

				video[params.hash] = x;

				createFile(function() {
					read_video(params.hash, callback);
					state_record(params.hash, params.playlist, null, DLBS_START);
				});

			}
			else {
				var host = params.playlist;
				var k = host.indexOf('?');
				if (k != -1) {
					host = host.substring(0, k);
				}
				k = host.lastIndexOf('/');
				if (k != -1) {
					host = host.substring(0, k+1);
				}
				//dump('host: '+host+'\n\n');

				var x = { 	host: 		host,
							url_m3u8:	params.playlist,
							url_hash:	params.hash,
							dir_path:	params.dirPath,
							file_path:	params.fileName,
							root_url:	params.rootUrl,
							referer:	params.referer,
							size:		0,
							stop:		false,
							endlist:	false,
							file:		[],
							queue:		0,
							state:		STREAM_PREPARING
						 };
				video[params.hash] = x;

				createFile(function() {
					start_record(params, callback);
					state_record(params.hash, params.playlist, null, DLBS_START);
				});
			}

			// ---------------------------
			function createFile(callback) {

				var encoder = new TextEncoder();
				var data =  Components.utils["import"]("resource://gre/modules/Services.jsm", {}).atob(params.initSeg ? params.initSeg : "");

				var aFile = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
				aFile.initWithPath(params.dirPath);
				aFile.append(params.fileName);
				aFile.createUnique(Components.interfaces.nsIFile.NORMAL_FILE_TYPE, 0600);
				var stream = Components.classes["@mozilla.org/network/safe-file-output-stream;1"].createInstance(Components.interfaces.nsIFileOutputStream);
				stream.init(aFile, 0x04 | 0x08 | 0x20, 0600, 0);    // readwrite, create, truncate
				stream.write(data, data.length);
				if (stream instanceof Components.interfaces.nsISafeOutputStream) {
					stream.finish();
				} else {
					stream.close();
				}
				callback();
			}

		}

		// -------------------------------------------------------------------------------------------------------
		function start_record(params, callback) 	{

			read_m3u8(params.hash, params.playlist, function(listUrl) {

				if ( !self.isVideo(params.hash) ) return callback(false);

				// составим список файлов к скачке
				var fl = false;
				for (var i=0; i<listUrl.length; i++) {
					var x = add_download_file( params.hash, listUrl[i] );
					if ( !x ) 	fl = true;
				}
				for (var i=0; i<video[params.hash].file.length; i++) video[params.hash].file[i].index = i;

				// запускаем процесс скачки
 				if (fl) {
					video[params.hash].state = STREAM_WORKING;
					read_video(params.hash, callback);
				}

			});

		};


		// -------------------------------------------------------------------------------------------------------
		function add_download_file( urlHash, fileName ) 	{

			var url, file_name;
			if ( fileName.indexOf( 'http' ) != -1 ) {
				url = fileName;

				var k = fileName.lastIndexOf( '/' );
				if (k == -1)  {
					file_name = fileName;
				}
				else {
					file_name = fileName.substring(k+1, fileName.length);
				}
			}
			else {
				url = video[urlHash].host + fileName;
				file_name = fileName;
			}

			for (var i=0; i<video[urlHash].file.length; i++) {
				if (video[urlHash].file[i].fileName == file_name) return true;
			}

			video[urlHash].file.push({	fileName: 	file_name.replace('/','_'),
										url:		url,
										id:			0,
										size:		0,
										hash:		urlHash,
										state:		0,
									});

			return false;

		}

		// -------------------------------------------------------------------------------------------------------
		function read_m3u8(urlHash, url_m3u8, callback) 	{
			//dump('read_m3u8: '+url_m3u8+'\n'+urlHash+'\n');
			if ( !self.isVideo(urlHash) ) return callback(false);
			var lastChunkUrl = video[urlHash].lastChunkUrl;
			fvd_single_Misc.readUrl(url_m3u8, function(data) {

				var results = [];

				data.split('\n').forEach(function( item ){

						if ( item.substring(0,1) == '#' )   return;
						item = item.trim();
						if ( !item )   return;
						var u = item;
						results.push( u );
				});

				callback(results);
			});
		}

		// -------------------------------------------------------------------------------------------------------
		function read_video(hash, callback) 	{

			//dump('read_video: '+hash+'  '+video[hash].queue+'   '+video[hash].state+'\n');

			if ( !self.isVideo(hash) ) return callback(false);

			if ( video[hash].queue < MIN_STREAM_DOWNLOAD && video[hash].state == STREAM_WORKING) {

				video[hash].state = STREAM_START_DOWNLOAD;

				for(var i = 0; i < video[hash].file.length; i++)     	{

					if (video[hash].file[i].state==0)      	{

						loadStreamFile(i);

						if (video[hash].queue >= MAX_STREAM_DOWNLOAD)  {  // очеред заполнили
							video[hash].state = STREAM_WORKING;
							return;
						}
					}
				}
			}

			// ------------------
			function loadStreamFile(ind) 	{

				video[hash].queue++;

				private_download(video[hash].file[ind].url, video[hash].dir_path, video[hash].file[ind].fileName, function( d, id ) {

					video[hash].file[ind].id = id;
					video[hash].file[ind].d = d;
					video[hash].file[ind].state = 1;

				}, function( dd ){

					if ( self.isVideo(hash) ) {

						video[hash].queue--;	// очередь скачки уменьшаем (на эту скачку)

						video[hash].file[ind].state = 2;
						video[hash].file[ind].size = dd.totalBytes;
						check_end_download(video[hash].file[ind].hash);
					}
				});

			}

		};


		// -------------------------------------------------------------------------------------------------------
		// проверим состояние закачки файлов
		function check_end_download(urlHash)	{

			//dump('check_end_download: '+urlHash+'\n');

			if (!video[urlHash]) return;

			if (video[urlHash].state == STREAM_SAVING) return;

			// проверяем считывается ли файлы
			var countLoad = 0;
			var flagEnd = true;
			var size = 0;
			for (let i=0; i<video[urlHash].file.length; i++) {

				if (video[urlHash].file[i].state > 1) countLoad++;			// скачано сегментов
				else flagEnd = false;

				size += video[urlHash].file[i].size;
			}

			video[urlHash].size = size;

			if (flagEnd) {
				video[urlHash].state == STREAM_FINALIZING;
				finalizing_download(urlHash);
			}
			else {
				state_record(urlHash, video[urlHash].url_m3u8, size, DLBS_DOWNLOADING);
				read_video(urlHash);
			}

		}

		// -------------------------------------------------------------------------------------------------------
		function private_download(url, dir_path, file_path, callback, callback_run) 	{

			//dump('===private_download: '+file_path+'\n'+url+'\n\n');

			var file =  new FileUtils.File(dir_path);
			file.append(file_path);
			file.createUnique(Components.interfaces.nsIFile.NORMAL_FILE_TYPE, FileUtils.PERMS_FILE);

			if( useNewStyle ){

				var promise = Downloads.createDownload({
					source: {
						url: 		url,
						isPrivate: 	false,
					},
					target: file.path,
				});

				promise.then( function( d ){

						d.path = file_path;

						try{
							d.start().then( function( ){

								//dump("Download finished successfully: "+d.path+"\n");

								callback_run(d);

							}, function( error ){
								dump( "Error while start download("+error.result+"), ("+error.becauseSourceFailed+")("+error.becauseTargetFailed+")\n" );
							} );
						}
						catch( ex ){
							dump( "FAIL START DOWNLOAD: " + ex + "\n" );
						}

						callback( d, _nextRecordId() );

					}, function(){
						//dump( "Promise rejected " + arguments.length + "\n" );
					}
				);
			}
			else {
				var targetPath = null;
				try {

					var ios = Components.classes['@mozilla.org/network/io-service;1'].getService(Components.interfaces.nsIIOService);
					var from_url = ios.newURI(url, null, null);

					var file = Components.classes['@mozilla.org/file/local;1'].createInstance(Components.interfaces.nsILocalFile);
					file.initWithPath(dir_path);
					file.append(file_path);
					targetPath = ios.newFileURI(file);

					var persist = Components.classes['@mozilla.org/embedding/browser/nsWebBrowserPersist;1'].createInstance(Components.interfaces.nsIWebBrowserPersist);
					persist.persistFlags = Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_REPLACE_EXISTING_FILES | Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_BYPASS_CACHE | Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_AUTODETECT_APPLY_CONVERSION;

					var d = dm.addDownload(dm.DOWNLOAD_TYPE_DOWNLOAD, from_url, targetPath, '', null, Math.round(Date.now() * 1000), null, persist, false);

					persist.progressListener = d.QueryInterface(Components.interfaces.nsIWebProgressListener);

					var windowMediator = Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator);
					var window = windowMediator.getMostRecentWindow("navigator:browser");
					var privacyContext = window.QueryInterface(Components.interfaces.nsIInterfaceRequestor).getInterface(Components.interfaces.nsIWebNavigation).QueryInterface(Components.interfaces.nsIInterfaceRequestor);
					persist.saveURI(d.source, null, null, null, null, d.targetFile, privacyContext);

					callback( d, d.id );
				}
				catch (ex) {
					dump('RECORDER: private_download: '+ex+'\n');
				}
			}

		}

		// -------------------------------------------------------------------------------------------------------
		function check_finalizing_download(urlHash)	{

			//dump('check_finalizing_download: '+urlHash+'\n');

			var dir_path  = video[urlHash].dir_path;

			var flag = false;
			for (var i=0; i<video[urlHash].file.length; i++) {
				// проверка на запуск download (id=1) и нет окончания загрузки load = false
				var ff = true;
				if ( video[urlHash].file[i].id > 0 ) {		// запущена на скачивание
					try {
						if ( video[urlHash].file[i].state == 1 )  {

							video[urlHash].file[i].state = 7;
							if( useNewStyle ){
								video[urlHash].file[i].d.cancel();
							}
							else {
								dm.cancelDownload( video[urlHash].file[i].d.id );
							}

							ff = false;
							video[urlHash].file[i].id = 0;
						}
						else {
							if (!ff) {								// до обрыва
								video[urlHash].file[i].id = 0;
								video[urlHash].file[i].state = 7;
								var f = dir_path + DIRECTORY_SEPARATOR + video[urlHash].file[i].fileName;
								remove_file( f );
							}
							else {
							    flag = true;
							}
						}
					} catch(e) {}
				}
			}

 			if (flag) {
				finalizing_download(urlHash);
			}
			else {
				var url_m3u8  = video[urlHash].url_m3u8;
				delete video[urlHash];

				state_record(urlHash, url_m3u8, null, DLBS_STOP);
			}
		}

		// -------------------------------------------------------------------------------------------------------
		function finalizing_download(urlHash) {

			dump('finalizing_download: '+urlHash+'   '+video[urlHash].file.length+'\n');

			if ( video[urlHash] ) {

				var file_path = video[urlHash].file_path;
				var url_m3u8  = video[urlHash].url_m3u8;
				var dir_path  = video[urlHash].dir_path;

				if (video[urlHash].file) {

					var list_file = [];

					for (let i=0; i<video[urlHash].file.length; i++) {
						if (video[urlHash].file[i].state == 2) {
							list_file.push(dir_path + DIRECTORY_SEPARATOR + video[urlHash].file[i].fileName);
						}
					}

					if (list_file.length > 0) {
						union_video(dir_path, file_path, list_file, function(status) {
							// удалим файлы
							for (var i=0; i<list_file.length; i++) {
								remove_file( list_file[i] );
							}

							// статус
							if (url_m3u8) {
								state_record(urlHash, url_m3u8, null, DLBS_STOP);
							}

							delete video[urlHash];

							// письмо о окончании закачки
							if (file_path) {
								state_record(urlHash, url_m3u8, file_path, DLBS_FINISH);
							}
						});
					}
					else {
						delete video[urlHash];
						state_record(urlHash, url_m3u8, null, DLBS_STOP);
					}
				}
			}
		}

		// -------------------------------------------------------------------------------------------------------
		function union_video( dir, file_path, list_file, callback ){

			dump('=union_video= '+dir+'  '+file_path+'\n');

			var file_main = dir + DIRECTORY_SEPARATOR + file_path;

			const {OS} = Components.utils.import("resource://gre/modules/osfile.jsm", {});

			OS.File.open( file_main, {write: true} ).then( function(file) {

				file.setPosition(0,OS.File.POS_END);

				var index = 0;

				function Next() {
					if(index >= list_file.length) {
						file.close();
						callback();
					}
					else  {
						OS.File.read(list_file[index++]).then(function(data) {
							file.write(data).then(Next, function(ex) {
								dump("STREAMS:I/O error(write):"+ex+'\n');
								file.close();
							});
						},function(ex) {
							dump("STREAMS:I/O error(read):"+ex+'\n');
							file.close();
						});
					}
				}

				Next();
			},function(ex) {
				dump("STREAMS: I/O error(open): \n"+ex.message+"\n"+ex.filename+"\n");
			});

		}

		// -------------------------------------------------------------------------------------------------------
		function read_sizeFile( dir, file_path, callback ){

			var file_main = dir + DIRECTORY_SEPARATOR + file_path;

			const {OS} = Components.utils.import("resource://gre/modules/osfile.jsm", {});

			let promise = OS.File.stat(file_main);
			promise.then(
				function onSuccess(info) { // |info| is an instance of |OS.File.Info|
					if (info.size) {
						callback(info.size);
					}
				},
				function onFailure(reason) {
					if (reason instanceof OS.File.Error && reason.becauseNoSuchFile) {
					}
					else {
					}
				}
			);

		}

		function prepareVideoSize( bytes ){

			if (bytes<102400) {		// 0..100 Kb
				return (Math.round( 10 * bytes / 1024 ) / 10).toString() + "Kb";
			}
			else if (bytes<1048576) {	// 100Kb .. 1Mb
				return (Math.round( bytes / 1024 )).toString() + "Kb";
			}
			else if (bytes<104857600) {		// 1Mb..100Mb
				return (Math.round( 10 * bytes / 1024 / 1024 ) / 10).toString() + "Mb";
			}
			else if (bytes<1073741824)  {	// 100Mb..1Gb
				return (Math.round( bytes / 1024 / 1024 )).toString() + "Mb";
			}
			else  {		// 1Gb..
				return (Math.round( 10 * bytes / 1024 / 1024 / 1024 ) / 10).toString() + "Gb";
			}

			return '';
		};



		// ---------------------------------   удалим файл  -----------------------------------------------------
		function remove_file( file_name)  {

			var f = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsIFile);
			f.initWithPath(file_name);
			try {
				if(f.exists()) {
					f.remove(true);
				}
				else {
					dump('REMOVE_FILE '+file_name+' - not found\n');
				}
			} catch(e){
				dump('REMOVE_FILE '+file_name+'\n'+e+'\n');
			}

		}

		// ---------------------------------     -----------------------------------------------------
		function state_record( urlHash, url_m3u8, size, state )  {

			// status
			if (state == DLBS_START) {	// start
				video[urlHash].size = 'preparing';
				run_state(urlHash, url_m3u8, 'preparing', state);
			}
			else if (state == DLBS_STOP) {	// stop
				run_state(urlHash, url_m3u8, null, state);
			}
			else if (state == DLBS_FINALIZY) {
				video[urlHash].size = 'finalizing';
				run_state(urlHash, url_m3u8, 'finalizing', state);
			}
			else if (state == DLBS_DOWNLOADING) {
				if (size) {
					if (video[urlHash]) video[urlHash].size = size;
					run_state(urlHash, url_m3u8, prepareVideoSize(size), state);
				}
			}
			else if (state == DLBS_FINISH) {
				run_state(urlHash, url_m3u8, size, DLBS_FINISH);
			}

		}

		function run_state( urlHash, url_m3u8, size, state ) {

			if (funcStreamState.length>0) {
				funcStreamState[0](urlHash, url_m3u8, size, state, video[urlHash] ? video[urlHash].root_url : null);
			}

		}

		// -------------------------------------------------------------------------------------------------------
		this.cancel_record = function(urlHash, url_m3u8 ){

			//dump('cancel_record'+urlHash+'\n');

			video[urlHash].stop = true;

			state_record(urlHash, url_m3u8, null, DLBS_FINALIZY);

			check_finalizing_download(urlHash);

		}

		// -------------------------------------------------------------------------------------------------------
		this.abort_record = function( root_url ){

			//dump('abortTwitchDownload: '+root_url+'\n');

			for (var urlHash in video) {

				if (video[urlHash].root_url == root_url) {

					dump('ABORT: '+urlHash+'\n');

					video[urlHash].stop = true;

					state_record(urlHash, video[urlHash].url_m3u8, null, FINALIZY);

					check_finalizing_download(urlHash);

				}
			}
		}

	};

}
