var EXPORTED_SYMBOLS = ["fvd_single_Records"];

Components.utils.import("resource://fvd.single.modules/async.js");
Components.utils.import("resource://fvd.single.modules/misc.js");
Components.utils.import("resource://fvd.single.modules/lib/fvdUtils.js");

try{
	Components.utils.import("resource://gre/modules/FileUtils.jsm");
}
catch( ex ){
	dump('ERROR: modules: '+ex+'\n');
}

try{
	var dm = Components.classes["@mozilla.org/download-manager;1"].getService(Components.interfaces.nsIDownloadManager);
}
catch( ex ){
	dump('ERROR: download-manager: '+ex+'\n');
}

var useNewStyle = false;

var appInfo = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULAppInfo);
var osString = Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULRuntime).OS;

var DIRECTORY_SEPARATOR = osString == "WINNT" ? "\\" : "/";

var majorV = appInfo.version.split(".")[0];
var browserName = appInfo.name.toLowerCase().replace(/\s/g,'');

if(osString == "Android") {
	if(majorV >= 37) {
		useNewStyle = true;
	}
}
else if ( browserName == 'palemoon' ) {
	useNewStyle = false;
}
else if(majorV >= 26) {
	useNewStyle = true;
}

if ( useNewStyle ) {
	try{
		Components.utils.import("resource://gre/modules/Downloads.jsm");
	}
	catch( ex ){
		dump('ERROR: downloads: '+ex+'\n');
	}
}


if (typeof fvd_single_Records == "undefined") {

	var fvd_single_Records = new function(){

		var self = this;

		var video = {};

		const DLBS_NORMAL = 0;
		const DLBS_DOWNLOADING = 1;
		const DLBS_START = 5;
		const DLBS_STOP = 6;
		const DLBS_FINALIZY = 7;
		const DLBS_FINISH = 8;

		var funcTwitchState = [];

		var oldStyleListeners = [];

		var _lastRecordId = 0;

		function _nextRecordId(){
			_lastRecordId++;

			return _lastRecordId;
		}


		// -------------------------------------------------------------------------------------------------------
		this.getVideoForId = function( id ) {

			for (var urlHash in video) {

				for (var i=0; i<video[urlHash].file.length; i++) {

					if (video[urlHash].file[i].id == id)  return video[urlHash].file[i];
				}
			}

			return null;
		};

		// -------------------------------------------------------------------------------------------------------
		this.statusPage = function( root_url ) {

			for (var urlHash in video) {

				if (video[urlHash].root_url == root_url) {
					if (!video[urlHash].stop && video[urlHash].file)  {
						for (var i=0; i<video[urlHash].file.length; i++) {
							if (video[urlHash].file[i].id>0)  return true;
						}
					}
				}

			}

			return false;
		};

		// -------------------------------------------------------------------------------------------------------
		this.isVideo = function( urlHash ) {

			if (video[urlHash] && !video[urlHash].stop) 	return true;

			return false;
		};

		// -------------------------------------------------------------------------------------------------------
		this.isVideoFinalizing = function( urlHash ) {

			if (video[urlHash] && !video[urlHash].stop && video[urlHash].size == 'finalizing') 	return true;

			return false;
		};

		// -------------------------------------------------------------------------------------------------------
		this.getSize = function( urlHash ) {

			if (video[urlHash]) {
				if (video[urlHash].size == 'finalizing')  return ' ( finalizing )';

				return ' ( '+prepareVideoSize(video[urlHash].size)+' MB)';
			}

			return '';
		};

		var _oldStyleListener = function(){

		};

		_oldStyleListener.prototype = {

			view: {},

			onProgressChange : function(prog, req, prog, progMax, tProg, tProgMax, dl)
			{
			},

			onSecurityChange : function(prog, req, prog, status, dl)
			{
			},

			onStateChange : function(prog, req, flags, status, dl)
			{
				var ff = self.getVideoForId( dl.id );
				if ( dl.state == Components.interfaces.nsIDownloadManager.DOWNLOAD_FINISHED ) {
					ff.load = true;
					check_end_download(ff.url_hash);
				}
			},

			onDownloadStateChange : function(state, dl)
			{
			}

		};

		// -------------------------------------------------------------------------------------------------------
		this.add_state = function( funcState ) {

			if( useNewStyle ){

				funcTwitchState.unshift(funcState);

			}
			else {
				var listener = new _oldStyleListener();
				listener.view = funcState;

				oldStyleListeners.push( listener );

				dm.addListener( listener );

				funcTwitchState.unshift(funcState);
			}

		};

		// -------------------------------------------------------------------------------------------------------
		this.remove_state = function( funcState ) {

			if (funcTwitchState.length>0 && funcTwitchState[0] == funcState) {

				funcTwitchState.shift(funcState);
			}

		};

		// -------------------------------------------------------------------------------------------------------
		this.start = function(params, callback) 	{

			//dump('\n\nstart: '+params.hash+'\n'+params.playlist+'\n'+params.dirPath+'  '+params.fileName+'\n'+params.rootUrl + "\n");

 			var host = params.playlist;
			var k = host.indexOf('?');
			if (k != -1) {
				host = host.substring(0, k);
			}
			k = host.lastIndexOf('/');
			if (k != -1) {
				host = host.substring(0, k+1);
			}
			//dump('host: '+host+'\n\n');

			var x = { 	host: 		host,
						url_m3u8:	params.playlist,
						url_hash:	params.hash,
						dir_path:	params.dirPath,
						file_path:	params.fileName,
						root_url:	params.rootUrl,
						referer:	params.referer,
						dwnl:		params.typeDwnl,
						size:		0,
						stop:		false,
						endlist:	false,
						file:		[],
					 };
			video[params.hash] = x;

			start_record(params.hash, params.playlist, params.dirPath, params.fileName, params.rootUrl, params.referer, callback);

			state_record(params.hash, params.playlist, null, DLBS_START);

		}

		// -------------------------------------------------------------------------------------------------------
		function add_download_ts( urlHash, url ) 	{
			// check chunk already downloaded(or in progress)
			for (var i=0; i<video[urlHash].file.length; i++) {
				if (video[urlHash].file[i].url == url) return true;
			}

			var fileName = url;
			if(!/^https?:\/\//.test(url)) {
				url = video[urlHash].host + url;
			}
			else {
				fileName = urlHash + "_part_" + video[urlHash].file.length + ".ts";
			}

			var k = fileName.indexOf('?');
			if (k != -1)   fileName=fileName.substring(0, k);

			video[urlHash].file.push({	fileName: 	fileName,
										url:		url,
										url_hash:	urlHash,
										id:			0,
										load:		false,
										union:		false,
										priv:		(video[urlHash].dwnl & 0x01) == 1 ? true : false,
									});

			return false;

		}

		// -------------------------------------------------------------------------------------------------------
		function start_record(urlHash, url_m3u8, dir_path, file_path, root_url, referer, callback) 	{

			//dump('start_record: '+url_m3u8+'\n'+urlHash+'\n');

			if ( !self.isVideo(urlHash) ) return callback(false);

			if ( video[urlHash].endlist ) return;

			read_m3u8(urlHash, url_m3u8, function(listUrl) {

				if ( !self.isVideo(urlHash) ) return callback(false);

				var fl = false;
				for (var i=0; i<listUrl.length; i++) {
					var x = add_download_ts( urlHash, listUrl[i] );
					if ( !x ) 	fl = true;
				}

				if (fl) {
					read_video(urlHash, url_m3u8, dir_path, file_path, referer, callback);
				}
				else {
					start_record(urlHash, url_m3u8, dir_path, file_path, root_url, referer, callback);
				}

			});

		};

		// -------------------------------------------------------------------------------------------------------
		function read_m3u8(urlHash, url_m3u8, callback) 	{
			//dump('read_m3u8: '+url_m3u8+'\n'+urlHash+'\n');
			if ( !self.isVideo(urlHash) ) return callback(false);
			var typeDownload = video[urlHash].dwnl;
			var lastChunkUrl = video[urlHash].lastChunkUrl;
			fvd_single_Misc.readUrl(url_m3u8, function(data) {
				var list = [];
				var str = data.split('\n');
				var kk = str.length;
					for (var i=0; i<kk; i++) 	{
					if (str[i] == '') continue;

					if (str[i].indexOf('EXTINF') != -1) {
						var u = str[i+1];
						list.push(u);
					}
					else if (str[i].indexOf('#EXT-X-ENDLIST') != -1) {
						video[urlHash].endlist = true;
					}
				}
				if(!lastChunkUrl) {
					// return last chunk
					if ((typeDownload & 0x02)>0) list = list.slice(-1);	   // стартует с текущего момента (последний chunk)
				}
				else {
					var index = list.indexOf(lastChunkUrl);
					if(index >= 0) {
						list = list.slice(index + 1);
					}
					else {
						dump("Can't find last chunk url in playlist!\n");
						list = list.slice(-1);
					}
				}
				if(list.length) {
					video[urlHash].lastChunkUrl = list[list.length - 1];
				}
				callback(list);
			});
		}

		// -------------------------------------------------------------------------------------------------------
		function read_video(urlHash, url_m3u8, dir_path, file_path, referer, callback) 	{

			//dump('read_video '+urlHash+'\n');

			if ( !self.isVideo(urlHash) ) return callback(false);

			var k = 0;

			fvd_single_async.arrayProcess(video[urlHash].file, function( tw, apNext) {

				if (tw.id == 0) {
					private_download(tw.url, dir_path, tw.fileName, tw.priv, function( d ) {

						//tw.id = _nextRecordId();
						tw.id = d;

						k++;

						apNext();

					}, function( dd ){

							tw.load = true;
							check_end_download(tw.url_hash);

						});
				}
				else {
					apNext();
				}
			},
			  function() {
				if ( !self.isVideo(urlHash) ) {
					callback(false);
				}
				else {
					if (k>0) {
						callback(true);
					}
					else {
						// следующий пакет
						start_record(urlHash, url_m3u8, dir_path, file_path, root_url, referer, callback);
					}
				}
			});
		};

		// -------------------------------------------------------------------------------------------------------
		function private_download(url, dir_path, file_path, priv, callback, callback_run) 	{

			//dump('===private_download: '+priv+' '+dir_path+' '+file_path+'\n'+url+'\n\n');

			var file =  new FileUtils.File(dir_path);
			file.append(file_path);
			file.createUnique(Components.interfaces.nsIFile.NORMAL_FILE_TYPE, FileUtils.PERMS_FILE);

			if( useNewStyle ){

				var promise = Downloads.createDownload({
					source: {
						url: 		url,
						isPrivate: 	priv,
					},
					target: file.path,
				});

				promise.then( function( d ){

						d.path = file_path;

						try{
							d.start().then( function( ){

								//dump("Download finished successfully: "+d.path+"\n");

								callback_run(d);

							}, function( error ){
								//dump( "Error while start download("+error.result+"), ("+error.becauseSourceFailed+")("+error.becauseTargetFailed+")\n" );
							} );
						}
						catch( ex ){
							dump( "FAIL START DOWNLOAD: " + ex + "\n" );
						}

						callback( _nextRecordId() );

					}, function(){
						//dump( "Promise rejected " + arguments.length + "\n" );
					}
				);
			}
			else {
				var targetPath = null;
				try {

					var ios = Components.classes['@mozilla.org/network/io-service;1'].getService(Components.interfaces.nsIIOService);
					var from_url = ios.newURI(url, null, null);

					var file = Components.classes['@mozilla.org/file/local;1'].createInstance(Components.interfaces.nsILocalFile);
					file.initWithPath(dir_path);
					file.append(file_path);
					targetPath = ios.newFileURI(file);

					var persist = Components.classes['@mozilla.org/embedding/browser/nsWebBrowserPersist;1'].createInstance(Components.interfaces.nsIWebBrowserPersist);
					persist.persistFlags = Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_REPLACE_EXISTING_FILES | Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_BYPASS_CACHE | Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_AUTODETECT_APPLY_CONVERSION;

					var d = dm.addDownload(dm.DOWNLOAD_TYPE_DOWNLOAD, from_url, targetPath, '', null, Math.round(Date.now() * 1000), null, persist, false);

					persist.progressListener = d.QueryInterface(Components.interfaces.nsIWebProgressListener);

					var windowMediator = Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator);
					var window = windowMediator.getMostRecentWindow("navigator:browser");
					var privacyContext = window.QueryInterface(Components.interfaces.nsIInterfaceRequestor).getInterface(Components.interfaces.nsIWebNavigation).QueryInterface(Components.interfaces.nsIInterfaceRequestor);
					persist.saveURI(d.source, null, null, null, null, d.targetFile, privacyContext);

					callback( d.id );
				}
				catch (ex) {
					dump('RECORDER: private_download: '+ex+'\n');
				}
			}

		}

		// -------------------------------------------------------------------------------------------------------
		function private_download_cancel(file_path, callback) 	{

			if( useNewStyle ){

				var d = Downloads.getList( Downloads.PUBLIC );

				d.then( function( d ){

					var a = d.getAll();

					a.then(function( dls ){

						for( var i = 0; i != dls.length; i++ ){

							if( dls[i].path == file_path ){
								dls[i].cancel();
								callback();
							}
						}
					});
				} );

			}
			else {
				dm.cancelDownload(  );
			}
		}

		// -------------------------------------------------------------------------------------------------------
		// проверим состояние закачки файлов
		function check_end_download(urlHash)	{

			//dump('check_end_download: '+urlHash+'\n');
			if (!video[urlHash]) return;

			// проверяем считывается ли файлы
			var flag = true;
			for (let i=0; i<video[urlHash].file.length; i++) {
				if (!video[urlHash].stop)  {
					if (video[urlHash].file[i].id>0 && !video[urlHash].file[i].load)  flag = false;	// этот файл запущен, но не скачен
				}
				else {
					if (!video[urlHash].file[i].load)  flag = false;	// этот файл не скачен
				}
			}

			// все файлы считаны -готовим список к объединению
			if (flag) {

				var dir_path 	= video[urlHash].dir_path;
				var file_path 	= video[urlHash].file_path;
				var url_m3u8 	= video[urlHash].url_m3u8;
				var root_url 	= video[urlHash].root_url;
				var referer 	= video[urlHash].referer;

				var list_file = [];

				for (let i=0; i<video[urlHash].file.length; i++) {
					if (!video[urlHash].file[i].union) {
						list_file.push(dir_path + DIRECTORY_SEPARATOR + video[urlHash].file[i].fileName);
						video[urlHash].file[i].union = true;	// метка объединения
					}
				}

				if (list_file.length > 0) {
					union_video(dir_path, file_path, list_file, function(status) {
						// удалим файлы
						for (var i=0; i<list_file.length; i++) {
							remove_file( list_file[i] );
						}
						// следующий пакет
						next_packet(urlHash, url_m3u8, dir_path, file_path, root_url, referer);
					});
				}
				else {
					// следующий пакет
					next_packet(urlHash, url_m3u8, dir_path, file_path, root_url, referer);
				}
			}
			// есть файл (который ожидает окончания загрузки)
		}

		// -------------------------------------------------------------------------------------------------------
		function next_packet(urlHash, url_m3u8, dir_path, file_path, root_url, referer)	{
			if ( self.isVideo(urlHash) ) {
				read_sizeFile( dir_path, file_path, function(size) {
					if (video[urlHash]) {
						state_record(urlHash, url_m3u8, size, DLBS_DOWNLOADING);
					}
				});

				if ( video[urlHash].endlist ) {
					finalizing_download(urlHash);
				}
				else {
					// следующий пакет
					start_record(urlHash, url_m3u8, dir_path, file_path, root_url, referer, function(id){ });
				}
			}
			else {
				finalizing_download(urlHash);
			}

		};

		// -------------------------------------------------------------------------------------------------------
		function check_finalizing_download(urlHash)	{

			//dump('check_finalizing_download_twitch_video: '+urlHash+'\n');

			var flag = true;
			for (var i=0; i<video[urlHash].file.length; i++) {
				// проверка на запуск download (id=1) и нет окончания загрузки load = false
				if (video[urlHash].file[i].id > 0 && !video[urlHash].file[i].load)  flag = false;
			}

			if (flag) {
				finalizing_download(urlHash);
			} else {
				check_end_download(urlHash);
			}
		}

		// -------------------------------------------------------------------------------------------------------
		function finalizing_download(urlHash) {
			if ( video[urlHash] ) {

				var file_path = video[urlHash].file_path;
				var url_m3u8  = video[urlHash].url_m3u8;
				var dir_path  = video[urlHash].dir_path;

				if (video[urlHash].file) {

					for (var i=0; i<video[urlHash].file.length; i++) {

						if ( !video[urlHash].file[i].union ) {
							remove_file( dir_path + DIRECTORY_SEPARATOR + video[urlHash].file[i].url );
						}

					}
				}

				if (url_m3u8) {
					state_record(urlHash, url_m3u8, null, DLBS_STOP);
				}

				delete video[urlHash];

				// письмо о окончании закачки
				if (file_path) {
					state_record(urlHash, url_m3u8, file_path, DLBS_FINISH);
				}
			}
		}

		// -------------------------------------------------------------------------------------------------------
		function union_video( dir, file_path, list_file, callback ){

			//dump('union video '+dir+'  '+file_path+'   '+list_file+'\n');

			var file_main = dir + DIRECTORY_SEPARATOR + file_path;

			try {
				const {OS} = Components.utils.import("resource://gre/modules/osfile.jsm", {});

				OS.File.open( file_main, {write: true, } ).then( function(file) {

					file.setPosition(0,OS.File.POS_END);

					var index = 0;

					function Next() {
						if(index >= list_file.length) {
							file.close();
							callback();
						}
						else  {
							OS.File.read(list_file[index++]).then(function(data) {
								file.write(data).then(Next, function(ex) {
									dump("RECORDS:I/O error(write):"+ex+'\n');
									file.close();
								});
							},function(ex) {
								dump("RECORDS:I/O error(read):"+ex+'\n');
								file.close();
							});
						}
					}

					Next();
				},function(ex) {
					dump("RECORDS: I/O error(open): \n"+ex.message+"\n"+ex.filename+"\n");
				});
			}
			catch(ex) {
				dump('RECORDS: union_video: '+ex+'\n');
			}

		}

		// -------------------------------------------------------------------------------------------------------
		function read_sizeFile( dir, file_path, callback ){

			var file_main = dir + DIRECTORY_SEPARATOR + file_path;

			const {OS} = Components.utils.import("resource://gre/modules/osfile.jsm", {});

			let promise = OS.File.stat(file_main);
			promise.then(
				function onSuccess(info) { // |info| is an instance of |OS.File.Info|
					if (info.size) {
						callback(info.size);
					}
				},
				function onFailure(reason) {
					if (reason instanceof OS.File.Error && reason.becauseNoSuchFile) {
					}
					else {
					}
				}
			);

		}

		function prepareVideoSize( bytes ){

			var mbytes = bytes / (1024 * 1024);
			mbytes = Math.round( mbytes * 100 )/100;

			return mbytes;
		};



		// ---------------------------------   удалим файл  -----------------------------------------------------
		function remove_file( file_name)  {

			var f = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsIFile);
			f.initWithPath(file_name);
			try {
				if(f.exists()) {
					f.remove(true);
				}
				else {
					dump('REMOVE_FILE '+file_name+' - not found\n');
				}
			} catch(e){
				dump('REMOVE_FILE '+file_name+'\n'+e+'\n');
			}

		}

		// ---------------------------------     -----------------------------------------------------
		function state_record( urlHash, url_m3u8, size, state )  {

			//dump('state_record: '+urlHash+'  '+url_m3u8+'  '+size+'  '+state+'   \n');
			// status
			if (state == DLBS_START) {	// start
				video[urlHash].size = '0';
				run_state(urlHash, url_m3u8, '(0 MB)', state);
			}
			else if (state == DLBS_STOP) {	// stop
				run_state(urlHash, url_m3u8, null, state);
			}
			else if (state == DLBS_FINALIZY) {
				video[urlHash].size = 'finalizing';
				run_state(urlHash, url_m3u8, '( finalizing )', state);
			}
			else if (state == DLBS_DOWNLOADING) {
				if (size) {
					if (video[urlHash]) video[urlHash].size = size;
					run_state(urlHash, url_m3u8, ' ('+prepareVideoSize(size)+' MB) ', state);
				}
			}
			else if (state == DLBS_FINISH) {
				run_state(urlHash, url_m3u8, size, DLBS_FINISH);
			}

		}

		function run_state( urlHash, url_m3u8, size, state ) {

			if (funcTwitchState.length>0) {
				funcTwitchState[0](urlHash, url_m3u8, size, state, video[urlHash] ? video[urlHash].root_url : null);
			}

		}

		// -------------------------------------------------------------------------------------------------------
		this.cancel_record = function(urlHash, url_m3u8 ){

			video[urlHash].stop = true;

			state_record(urlHash, url_m3u8, null, DLBS_FINALIZY);

			check_finalizing_download(urlHash);

		}

		// -------------------------------------------------------------------------------------------------------
		this.abort_record = function( root_url ){

			//dump('abortTwitchDownload: '+root_url+'\n');

			for (var urlHash in video) {

				if (video[urlHash].root_url == root_url) {

					dump('ABORT: '+urlHash+'\n');

					video[urlHash].stop = true;

					state_record(urlHash, video[urlHash].url_m3u8, null, FINALIZY);

					check_finalizing_download(urlHash);

				}
			}
		}

	};

}
