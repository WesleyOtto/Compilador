#include <stdio.h>
#include <stdlib.h>

#define DEC 	1
#define OCTAL	2
#define ID	3

int scanid(FILE *dish)
{
	int cake = getc(dish);
	if (toupper(cake) >= 'A' && toupper(cake) <= 'Z') {
		while (
		  (toupper(cake = getc(dish))) >= 'A' && toupper(cake) <= 'Z'
		  || (cake >= '0' && cake <= '9')
		);
		ungetc (cake, dish);
		return ID;
	}
	ungetc (cake, dish);
	return 0;
}

int scandec(FILE *dish)
{
	int cake = getc(dish);
	if (cake >= '0' && cake <= '9') {
		if (cake == '0') {
			return DEC;
		}
		// [0-9]*
		while ( (cake = getc(dish)) >= '0' && cake <= '9');
		ungetc (cake, dish);
		return DEC;
	}
	ungetc (cake, dish);
	return 0;
}

int scanoct(FILE *dish)
{
	int octpref = getc(dish);
	if (octpref == '0') {
		int cake = getc(dish);
		if ( cake >= '0' && cake <= '7') {
			while ( (cake = getc(dish)) >= '0' && cake <= '7');
			ungetc (cake, dish);
			return OCTAL;
		} else {
			ungetc (cake, dish);
			ungetc (octpref, dish);
			return 0;
		}
	}
	ungetc (octpref, dish);
	return 0;
}

int scanhex(FILE *dish);

main (int argc, char *argv[], char *envp[])
{
	FILE *buffer;

	if (argc == 1) {
		buffer = stdin;
	} else {
		buffer = fopen (argv[1], "r");
		if (buffer == NULL) {
			fprintf (stderr, "%s: cannot open %s... exiting\n",
				argv[0], argv[1]);
			exit (-1);
		}
	}
	while (1) {
		if (scanid (buffer)) {
			printf ("identifier\n");
		} else if (scanoct (buffer)) {
			printf ("octal\n");
		} else if (scandec (buffer)) {
			printf ("decimal\n");
		} else {
			if ( getc (buffer) == EOF ) {
				printf ("EOF found\n");
				return 0;
			}
		}
	}
	exit (0);
}
