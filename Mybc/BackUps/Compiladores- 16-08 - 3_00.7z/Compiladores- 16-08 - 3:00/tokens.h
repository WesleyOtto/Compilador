enum {
	ID = 1025,
	DEC,
	OCTAL,
};

enum {
	SYNTAX_ERR = -64,
};
